/**
 */
package Maze.tests;

import Maze.MazeFactory;
import Maze.RectangleGenerator;

import junit.framework.TestCase;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Rectangle Generator</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class RectangleGeneratorTest extends TestCase {

	/**
	 * The fixture for this Rectangle Generator test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RectangleGenerator fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(RectangleGeneratorTest.class);
	}

	/**
	 * Constructs a new Rectangle Generator test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RectangleGeneratorTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Rectangle Generator test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(RectangleGenerator fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Rectangle Generator test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RectangleGenerator getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(MazeFactory.eINSTANCE.createRectangleGenerator());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //RectangleGeneratorTest
