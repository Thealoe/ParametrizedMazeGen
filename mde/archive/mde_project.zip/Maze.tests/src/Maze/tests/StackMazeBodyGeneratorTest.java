/**
 */
package Maze.tests;

import Maze.MazeFactory;
import Maze.StackMazeBodyGenerator;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Stack Maze Body Generator</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class StackMazeBodyGeneratorTest extends MazeBodyGeneratorTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(StackMazeBodyGeneratorTest.class);
	}

	/**
	 * Constructs a new Stack Maze Body Generator test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StackMazeBodyGeneratorTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Stack Maze Body Generator test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected StackMazeBodyGenerator getFixture() {
		return (StackMazeBodyGenerator)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(MazeFactory.eINSTANCE.createStackMazeBodyGenerator());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //StackMazeBodyGeneratorTest
