/**
 */
package Maze.tests;

import Maze.MazeBodyGenerator;

import junit.framework.TestCase;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Body Generator</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class MazeBodyGeneratorTest extends TestCase {

	/**
	 * The fixture for this Body Generator test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MazeBodyGenerator fixture = null;

	/**
	 * Constructs a new Body Generator test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MazeBodyGeneratorTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Body Generator test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(MazeBodyGenerator fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Body Generator test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MazeBodyGenerator getFixture() {
		return fixture;
	}

} //MazeBodyGeneratorTest
