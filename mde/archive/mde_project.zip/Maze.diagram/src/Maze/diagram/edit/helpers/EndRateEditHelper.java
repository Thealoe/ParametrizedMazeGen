/*
 * 
 */
package Maze.diagram.edit.helpers;

/**
 * @generated
 */
public class EndRateEditHelper extends Maze.diagram.edit.helpers.MazeBaseEditHelper {
}
