/*
 * 
 */
package Maze.diagram.edit.helpers;

/**
 * @generated
 */
public class RectangleGeneratorEditHelper extends Maze.diagram.edit.helpers.MazeBaseEditHelper {
}
