/*
* 
*/
package Maze.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class MazeBodyGeneratorMazeBodyGeneratorTrCompartmentItemSemanticEditPolicy
		extends Maze.diagram.edit.policies.MazeBaseItemSemanticEditPolicy {

	/**
	* @generated
	*/
	public MazeBodyGeneratorMazeBodyGeneratorTrCompartmentItemSemanticEditPolicy() {
		super(Maze.diagram.providers.MazeElementTypes.MazeBodyGenerator_2004);
	}

	/**
	* @generated
	*/
	protected Command getCreateCommand(CreateElementRequest req) {
		if (Maze.diagram.providers.MazeElementTypes.TurnRate_3012 == req.getElementType()) {
			return getGEFWrapper(new Maze.diagram.edit.commands.TurnRate2CreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
