/*
 * 
 */
package Maze.diagram.edit.helpers;

/**
 * @generated
 */
public class EndPointEditHelper extends Maze.diagram.edit.helpers.MazeBaseEditHelper {
}
