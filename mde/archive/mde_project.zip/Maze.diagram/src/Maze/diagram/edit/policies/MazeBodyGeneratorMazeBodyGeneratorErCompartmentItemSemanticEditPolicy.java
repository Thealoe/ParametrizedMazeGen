/*
* 
*/
package Maze.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class MazeBodyGeneratorMazeBodyGeneratorErCompartmentItemSemanticEditPolicy
		extends Maze.diagram.edit.policies.MazeBaseItemSemanticEditPolicy {

	/**
	* @generated
	*/
	public MazeBodyGeneratorMazeBodyGeneratorErCompartmentItemSemanticEditPolicy() {
		super(Maze.diagram.providers.MazeElementTypes.MazeBodyGenerator_2004);
	}

	/**
	* @generated
	*/
	protected Command getCreateCommand(CreateElementRequest req) {
		if (Maze.diagram.providers.MazeElementTypes.EndRate_3013 == req.getElementType()) {
			return getGEFWrapper(new Maze.diagram.edit.commands.EndRateCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
