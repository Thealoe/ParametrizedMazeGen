/*
 * 
 */
package Maze.diagram.edit.helpers;

/**
 * @generated
 */
public class ColumnCountEditHelper extends Maze.diagram.edit.helpers.MazeBaseEditHelper {
}
