/*
 * 
 */
package Maze.diagram.edit.helpers;

/**
 * @generated
 */
public class MazeCellEditHelper extends Maze.diagram.edit.helpers.MazeBaseEditHelper {
}
