/*
 * 
 */
package Maze.diagram.edit.helpers;

/**
 * @generated
 */
public class SolutionPathGeneratorEditHelper extends Maze.diagram.edit.helpers.MazeBaseEditHelper {
}
