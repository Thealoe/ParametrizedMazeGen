/*
 * 
 */
package Maze.diagram.edit.helpers;

/**
 * @generated
 */
public class StackMazeBodyGeneratorEditHelper extends Maze.diagram.edit.helpers.MazeBaseEditHelper {
}
