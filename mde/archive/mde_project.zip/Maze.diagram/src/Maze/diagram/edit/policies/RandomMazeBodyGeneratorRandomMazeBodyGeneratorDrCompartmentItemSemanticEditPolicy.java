/*
* 
*/
package Maze.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class RandomMazeBodyGeneratorRandomMazeBodyGeneratorDrCompartmentItemSemanticEditPolicy
		extends Maze.diagram.edit.policies.MazeBaseItemSemanticEditPolicy {

	/**
	* @generated
	*/
	public RandomMazeBodyGeneratorRandomMazeBodyGeneratorDrCompartmentItemSemanticEditPolicy() {
		super(Maze.diagram.providers.MazeElementTypes.RandomMazeBodyGenerator_2006);
	}

	/**
	* @generated
	*/
	protected Command getCreateCommand(CreateElementRequest req) {
		if (Maze.diagram.providers.MazeElementTypes.DecisionsRate_3001 == req.getElementType()) {
			return getGEFWrapper(new Maze.diagram.edit.commands.DecisionsRateCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
