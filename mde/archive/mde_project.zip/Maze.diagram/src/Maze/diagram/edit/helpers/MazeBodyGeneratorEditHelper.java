/*
 * 
 */
package Maze.diagram.edit.helpers;

/**
 * @generated
 */
public class MazeBodyGeneratorEditHelper extends Maze.diagram.edit.helpers.MazeBaseEditHelper {
}
