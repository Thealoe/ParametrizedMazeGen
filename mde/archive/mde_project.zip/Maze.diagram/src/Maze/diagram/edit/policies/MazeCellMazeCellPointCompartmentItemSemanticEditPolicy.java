/*
* 
*/
package Maze.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class MazeCellMazeCellPointCompartmentItemSemanticEditPolicy
		extends Maze.diagram.edit.policies.MazeBaseItemSemanticEditPolicy {

	/**
	* @generated
	*/
	public MazeCellMazeCellPointCompartmentItemSemanticEditPolicy() {
		super(Maze.diagram.providers.MazeElementTypes.MazeCell_3003);
	}

	/**
	* @generated
	*/
	protected Command getCreateCommand(CreateElementRequest req) {
		if (Maze.diagram.providers.MazeElementTypes.CellPoint_3004 == req.getElementType()) {
			return getGEFWrapper(new Maze.diagram.edit.commands.CellPointCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
