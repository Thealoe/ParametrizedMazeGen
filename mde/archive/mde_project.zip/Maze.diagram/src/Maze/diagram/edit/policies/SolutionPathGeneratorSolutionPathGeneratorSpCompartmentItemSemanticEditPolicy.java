/*
* 
*/
package Maze.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class SolutionPathGeneratorSolutionPathGeneratorSpCompartmentItemSemanticEditPolicy
		extends Maze.diagram.edit.policies.MazeBaseItemSemanticEditPolicy {

	/**
	* @generated
	*/
	public SolutionPathGeneratorSolutionPathGeneratorSpCompartmentItemSemanticEditPolicy() {
		super(Maze.diagram.providers.MazeElementTypes.SolutionPathGenerator_2004);
	}

	/**
	* @generated
	*/
	protected Command getCreateCommand(CreateElementRequest req) {
		if (Maze.diagram.providers.MazeElementTypes.StartPoint_3010 == req.getElementType()) {
			return getGEFWrapper(new Maze.diagram.edit.commands.StartPointCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
