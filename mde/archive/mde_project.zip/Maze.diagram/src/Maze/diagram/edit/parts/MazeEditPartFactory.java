/*
 * 
 */
package Maze.diagram.edit.parts;

import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPartFactory;
import org.eclipse.gef.tools.CellEditorLocator;
import org.eclipse.gmf.runtime.diagram.ui.editparts.ITextAwareEditPart;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.gmf.tooling.runtime.directedit.locator.CellEditorLocatorAccess;

/**
 * @generated
 */
public class MazeEditPartFactory implements EditPartFactory {

	/**
	* @generated
	*/
	public EditPart createEditPart(EditPart context, Object model) {
		if (model instanceof View) {
			View view = (View) model;
			switch (Maze.diagram.part.MazeVisualIDRegistry.getVisualID(view)) {

			case Maze.diagram.edit.parts.MazeDiagramEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.MazeDiagramEditPart(view);

			case Maze.diagram.edit.parts.StackMazeBodyGeneratorEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.StackMazeBodyGeneratorEditPart(view);

			case Maze.diagram.edit.parts.StackMazeBodyGeneratorType_nameEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.StackMazeBodyGeneratorType_nameEditPart(view);

			case Maze.diagram.edit.parts.RandomMazeBodyGeneratorEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.RandomMazeBodyGeneratorEditPart(view);

			case Maze.diagram.edit.parts.RandomMazeBodyGeneratorType_nameEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.RandomMazeBodyGeneratorType_nameEditPart(view);

			case Maze.diagram.edit.parts.RectangleGeneratorEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.RectangleGeneratorEditPart(view);

			case Maze.diagram.edit.parts.RectangleGeneratorNameEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.RectangleGeneratorNameEditPart(view);

			case Maze.diagram.edit.parts.SolutionPathGeneratorEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.SolutionPathGeneratorEditPart(view);

			case Maze.diagram.edit.parts.SolutionPathGeneratorNameEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.SolutionPathGeneratorNameEditPart(view);

			case Maze.diagram.edit.parts.DecisionsRateEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.DecisionsRateEditPart(view);

			case Maze.diagram.edit.parts.DecisionsRateNameEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.DecisionsRateNameEditPart(view);

			case Maze.diagram.edit.parts.StraightRateEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.StraightRateEditPart(view);

			case Maze.diagram.edit.parts.StraightRateNameEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.StraightRateNameEditPart(view);

			case Maze.diagram.edit.parts.TurnRateEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.TurnRateEditPart(view);

			case Maze.diagram.edit.parts.TurnRateNameEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.TurnRateNameEditPart(view);

			case Maze.diagram.edit.parts.EndRateEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.EndRateEditPart(view);

			case Maze.diagram.edit.parts.EndRateNameEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.EndRateNameEditPart(view);

			case Maze.diagram.edit.parts.RowCountEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.RowCountEditPart(view);

			case Maze.diagram.edit.parts.RowCountNameEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.RowCountNameEditPart(view);

			case Maze.diagram.edit.parts.ColumnCountEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.ColumnCountEditPart(view);

			case Maze.diagram.edit.parts.ColumnCountNameEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.ColumnCountNameEditPart(view);

			case Maze.diagram.edit.parts.TurnRate2EditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.TurnRate2EditPart(view);

			case Maze.diagram.edit.parts.TurnRateName2EditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.TurnRateName2EditPart(view);

			case Maze.diagram.edit.parts.StraightRate2EditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.StraightRate2EditPart(view);

			case Maze.diagram.edit.parts.StraightRateName2EditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.StraightRateName2EditPart(view);

			case Maze.diagram.edit.parts.DecisionsRate2EditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.DecisionsRate2EditPart(view);

			case Maze.diagram.edit.parts.DecisionsRateName2EditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.DecisionsRateName2EditPart(view);

			case Maze.diagram.edit.parts.StartPointEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.StartPointEditPart(view);

			case Maze.diagram.edit.parts.StartPointNameEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.StartPointNameEditPart(view);

			case Maze.diagram.edit.parts.EndPointEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.EndPointEditPart(view);

			case Maze.diagram.edit.parts.EndPointNameEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.EndPointNameEditPart(view);

			case Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorDrCompartmentEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorDrCompartmentEditPart(
						view);

			case Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorSrCompartmentEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorSrCompartmentEditPart(
						view);

			case Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorTrCompartmentEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorTrCompartmentEditPart(
						view);

			case Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorErCompartmentEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorErCompartmentEditPart(
						view);

			case Maze.diagram.edit.parts.RandomMazeBodyGeneratorRandomMazeBodyGeneratorDrCompartmentEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.RandomMazeBodyGeneratorRandomMazeBodyGeneratorDrCompartmentEditPart(
						view);

			case Maze.diagram.edit.parts.RandomMazeBodyGeneratorRandomMazeBodyGeneratorSrCompartmentEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.RandomMazeBodyGeneratorRandomMazeBodyGeneratorSrCompartmentEditPart(
						view);

			case Maze.diagram.edit.parts.RandomMazeBodyGeneratorRandomMazeBodyGeneratorTrCompartmentEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.RandomMazeBodyGeneratorRandomMazeBodyGeneratorTrCompartmentEditPart(
						view);

			case Maze.diagram.edit.parts.RandomMazeBodyGeneratorRandomMazeBodyGeneratorErCompartmentEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.RandomMazeBodyGeneratorRandomMazeBodyGeneratorErCompartmentEditPart(
						view);

			case Maze.diagram.edit.parts.RectangleGeneratorRectangleGeneratorRcCompartmentEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.RectangleGeneratorRectangleGeneratorRcCompartmentEditPart(view);

			case Maze.diagram.edit.parts.RectangleGeneratorRectangleGeneratorCcCompartmentEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.RectangleGeneratorRectangleGeneratorCcCompartmentEditPart(view);

			case Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorTrCompartmentEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorTrCompartmentEditPart(
						view);

			case Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorSrCompartmentEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorSrCompartmentEditPart(
						view);

			case Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorDrCompartmentEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorDrCompartmentEditPart(
						view);

			case Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorSpCompartmentEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorSpCompartmentEditPart(
						view);

			case Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorEpCompartmentEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorEpCompartmentEditPart(
						view);

			case Maze.diagram.edit.parts.RectangleGeneratorSpgEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.RectangleGeneratorSpgEditPart(view);

			case Maze.diagram.edit.parts.WrappingLabelEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.WrappingLabelEditPart(view);

			case Maze.diagram.edit.parts.SolutionPathGeneratorMbgEditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.SolutionPathGeneratorMbgEditPart(view);

			case Maze.diagram.edit.parts.WrappingLabel2EditPart.VISUAL_ID:
				return new Maze.diagram.edit.parts.WrappingLabel2EditPart(view);

			}
		}
		return createUnrecognizedEditPart(context, model);
	}

	/**
	* @generated
	*/
	private EditPart createUnrecognizedEditPart(EditPart context, Object model) {
		// Handle creation of unrecognized child node EditParts here
		return null;
	}

	/**
	* @generated
	*/
	public static CellEditorLocator getTextCellEditorLocator(ITextAwareEditPart source) {
		return CellEditorLocatorAccess.INSTANCE.getTextCellEditorLocator(source);
	}

}
