/*
 * 
 */
package Maze.diagram.edit.helpers;

/**
 * @generated
 */
public class RandomMazeBodyGeneratorEditHelper extends Maze.diagram.edit.helpers.MazeBaseEditHelper {
}
