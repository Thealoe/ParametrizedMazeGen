/*
* 
*/
package Maze.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class ForcePatternGeneratorForcePatternGeneratorMazeCellsCompartmentItemSemanticEditPolicy
		extends Maze.diagram.edit.policies.MazeBaseItemSemanticEditPolicy {

	/**
	* @generated
	*/
	public ForcePatternGeneratorForcePatternGeneratorMazeCellsCompartmentItemSemanticEditPolicy() {
		super(Maze.diagram.providers.MazeElementTypes.ForcePatternGenerator_2002);
	}

	/**
	* @generated
	*/
	protected Command getCreateCommand(CreateElementRequest req) {
		if (Maze.diagram.providers.MazeElementTypes.MazeCell_3003 == req.getElementType()) {
			return getGEFWrapper(new Maze.diagram.edit.commands.MazeCellCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
