/*
 * 
 */
package Maze.diagram.edit.helpers;

/**
 * @generated
 */
public class StraightRateEditHelper extends Maze.diagram.edit.helpers.MazeBaseEditHelper {
}
