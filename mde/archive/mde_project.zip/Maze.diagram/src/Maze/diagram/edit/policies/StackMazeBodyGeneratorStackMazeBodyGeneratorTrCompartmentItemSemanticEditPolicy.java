/*
* 
*/
package Maze.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class StackMazeBodyGeneratorStackMazeBodyGeneratorTrCompartmentItemSemanticEditPolicy
		extends Maze.diagram.edit.policies.MazeBaseItemSemanticEditPolicy {

	/**
	* @generated
	*/
	public StackMazeBodyGeneratorStackMazeBodyGeneratorTrCompartmentItemSemanticEditPolicy() {
		super(Maze.diagram.providers.MazeElementTypes.StackMazeBodyGenerator_2005);
	}

	/**
	* @generated
	*/
	protected Command getCreateCommand(CreateElementRequest req) {
		if (Maze.diagram.providers.MazeElementTypes.TurnRate_3003 == req.getElementType()) {
			return getGEFWrapper(new Maze.diagram.edit.commands.TurnRateCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
