/*
 * 
 */
package Maze.diagram.edit.helpers;

/**
 * @generated
 */
public class TurnRateEditHelper extends Maze.diagram.edit.helpers.MazeBaseEditHelper {
}
