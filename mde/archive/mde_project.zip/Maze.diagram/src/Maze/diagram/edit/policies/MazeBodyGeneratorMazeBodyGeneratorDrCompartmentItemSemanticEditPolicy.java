/*
* 
*/
package Maze.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class MazeBodyGeneratorMazeBodyGeneratorDrCompartmentItemSemanticEditPolicy
		extends Maze.diagram.edit.policies.MazeBaseItemSemanticEditPolicy {

	/**
	* @generated
	*/
	public MazeBodyGeneratorMazeBodyGeneratorDrCompartmentItemSemanticEditPolicy() {
		super(Maze.diagram.providers.MazeElementTypes.MazeBodyGenerator_2004);
	}

	/**
	* @generated
	*/
	protected Command getCreateCommand(CreateElementRequest req) {
		if (Maze.diagram.providers.MazeElementTypes.DecisionsRate_3010 == req.getElementType()) {
			return getGEFWrapper(new Maze.diagram.edit.commands.DecisionsRate2CreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
