/*
* 
*/
package Maze.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class RectangleGeneratorRectangleGeneratorRcCompartmentItemSemanticEditPolicy
		extends Maze.diagram.edit.policies.MazeBaseItemSemanticEditPolicy {

	/**
	* @generated
	*/
	public RectangleGeneratorRectangleGeneratorRcCompartmentItemSemanticEditPolicy() {
		super(Maze.diagram.providers.MazeElementTypes.RectangleGenerator_2003);
	}

	/**
	* @generated
	*/
	protected Command getCreateCommand(CreateElementRequest req) {
		if (Maze.diagram.providers.MazeElementTypes.RowCount_3004 == req.getElementType()) {
			return getGEFWrapper(new Maze.diagram.edit.commands.RowCountCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
