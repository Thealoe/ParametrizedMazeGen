/*
 * 
 */
package Maze.diagram.edit.parts;

import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.MarginBorder;
import org.eclipse.draw2d.RectangleFigure;
import org.eclipse.draw2d.Shape;
import org.eclipse.draw2d.StackLayout;
import org.eclipse.draw2d.geometry.Dimension;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPolicy;
import org.eclipse.gef.Request;
import org.eclipse.gef.commands.Command;
import org.eclipse.gef.editpolicies.LayoutEditPolicy;
import org.eclipse.gef.editpolicies.NonResizableEditPolicy;
import org.eclipse.gef.requests.CreateRequest;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.diagram.ui.editparts.ShapeNodeEditPart;
import org.eclipse.gmf.runtime.diagram.ui.editpolicies.EditPolicyRoles;
import org.eclipse.gmf.runtime.draw2d.ui.figures.ConstrainedToolbarLayout;
import org.eclipse.gmf.runtime.draw2d.ui.figures.WrappingLabel;
import org.eclipse.gmf.runtime.gef.ui.figures.DefaultSizeNodeFigure;
import org.eclipse.gmf.runtime.gef.ui.figures.NodeFigure;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.swt.graphics.Color;

/**
 * @generated
 */
public class StackMazeBodyGeneratorEditPart extends ShapeNodeEditPart {

	/**
	* @generated
	*/
	public static final int VISUAL_ID = 2005;

	/**
	* @generated
	*/
	protected IFigure contentPane;

	/**
	* @generated
	*/
	protected IFigure primaryShape;

	/**
	* @generated
	*/
	public StackMazeBodyGeneratorEditPart(View view) {
		super(view);
	}

	/**
	* @generated
	*/
	protected void createDefaultEditPolicies() {
		super.createDefaultEditPolicies();
		installEditPolicy(EditPolicyRoles.SEMANTIC_ROLE,
				new Maze.diagram.edit.policies.StackMazeBodyGeneratorItemSemanticEditPolicy());
		installEditPolicy(EditPolicy.LAYOUT_ROLE, createLayoutEditPolicy());
		installEditPolicy(EditPolicyRoles.OPEN_ROLE, new Maze.diagram.edit.policies.OpenDiagramEditPolicy()); // XXX need an SCR to runtime to have another abstract superclass that would let children add reasonable editpolicies
		// removeEditPolicy(org.eclipse.gmf.runtime.diagram.ui.editpolicies.EditPolicyRoles.CONNECTION_HANDLES_ROLE);
	}

	/**
	* @generated
	*/
	protected LayoutEditPolicy createLayoutEditPolicy() {
		org.eclipse.gmf.runtime.diagram.ui.editpolicies.LayoutEditPolicy lep = new org.eclipse.gmf.runtime.diagram.ui.editpolicies.LayoutEditPolicy() {

			protected EditPolicy createChildEditPolicy(EditPart child) {
				EditPolicy result = child.getEditPolicy(EditPolicy.PRIMARY_DRAG_ROLE);
				if (result == null) {
					result = new NonResizableEditPolicy();
				}
				return result;
			}

			protected Command getMoveChildrenCommand(Request request) {
				return null;
			}

			protected Command getCreateCommand(CreateRequest request) {
				return null;
			}
		};
		return lep;
	}

	/**
	* @generated
	*/
	protected IFigure createNodeShape() {
		return primaryShape = new StackMazeBodyGeneratorFigure();
	}

	/**
	* @generated
	*/
	public StackMazeBodyGeneratorFigure getPrimaryShape() {
		return (StackMazeBodyGeneratorFigure) primaryShape;
	}

	/**
	* @generated
	*/
	protected boolean addFixedChild(EditPart childEditPart) {
		if (childEditPart instanceof Maze.diagram.edit.parts.StackMazeBodyGeneratorType_nameEditPart) {
			((Maze.diagram.edit.parts.StackMazeBodyGeneratorType_nameEditPart) childEditPart)
					.setLabel(getPrimaryShape().getFigureStackMazeBodyGeneratorLabelFigure());
			return true;
		}
		if (childEditPart instanceof Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorDrCompartmentEditPart) {
			IFigure pane = getPrimaryShape().getStackMazeBodyGeneratorDrCompartmentFigure();
			setupContentPane(pane); // FIXME each comparment should handle his content pane in his own way 
			pane.add(
					((Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorDrCompartmentEditPart) childEditPart)
							.getFigure());
			return true;
		}
		if (childEditPart instanceof Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorSrCompartmentEditPart) {
			IFigure pane = getPrimaryShape().getStackMazeBodyGeneratorSrCompartmentFigure();
			setupContentPane(pane); // FIXME each comparment should handle his content pane in his own way 
			pane.add(
					((Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorSrCompartmentEditPart) childEditPart)
							.getFigure());
			return true;
		}
		if (childEditPart instanceof Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorTrCompartmentEditPart) {
			IFigure pane = getPrimaryShape().getStackMazeBodyGeneratorTrCompartmentFigure();
			setupContentPane(pane); // FIXME each comparment should handle his content pane in his own way 
			pane.add(
					((Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorTrCompartmentEditPart) childEditPart)
							.getFigure());
			return true;
		}
		if (childEditPart instanceof Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorErCompartmentEditPart) {
			IFigure pane = getPrimaryShape().getStackMazeBodyGeneratorErCompartmentFigure();
			setupContentPane(pane); // FIXME each comparment should handle his content pane in his own way 
			pane.add(
					((Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorErCompartmentEditPart) childEditPart)
							.getFigure());
			return true;
		}
		return false;
	}

	/**
	* @generated
	*/
	protected boolean removeFixedChild(EditPart childEditPart) {
		if (childEditPart instanceof Maze.diagram.edit.parts.StackMazeBodyGeneratorType_nameEditPart) {
			return true;
		}
		if (childEditPart instanceof Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorDrCompartmentEditPart) {
			IFigure pane = getPrimaryShape().getStackMazeBodyGeneratorDrCompartmentFigure();
			pane.remove(
					((Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorDrCompartmentEditPart) childEditPart)
							.getFigure());
			return true;
		}
		if (childEditPart instanceof Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorSrCompartmentEditPart) {
			IFigure pane = getPrimaryShape().getStackMazeBodyGeneratorSrCompartmentFigure();
			pane.remove(
					((Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorSrCompartmentEditPart) childEditPart)
							.getFigure());
			return true;
		}
		if (childEditPart instanceof Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorTrCompartmentEditPart) {
			IFigure pane = getPrimaryShape().getStackMazeBodyGeneratorTrCompartmentFigure();
			pane.remove(
					((Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorTrCompartmentEditPart) childEditPart)
							.getFigure());
			return true;
		}
		if (childEditPart instanceof Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorErCompartmentEditPart) {
			IFigure pane = getPrimaryShape().getStackMazeBodyGeneratorErCompartmentFigure();
			pane.remove(
					((Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorErCompartmentEditPart) childEditPart)
							.getFigure());
			return true;
		}
		return false;
	}

	/**
	* @generated
	*/
	protected void addChildVisual(EditPart childEditPart, int index) {
		if (addFixedChild(childEditPart)) {
			return;
		}
		super.addChildVisual(childEditPart, -1);
	}

	/**
	* @generated
	*/
	protected void removeChildVisual(EditPart childEditPart) {
		if (removeFixedChild(childEditPart)) {
			return;
		}
		super.removeChildVisual(childEditPart);
	}

	/**
	* @generated
	*/
	protected IFigure getContentPaneFor(IGraphicalEditPart editPart) {
		if (editPart instanceof Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorDrCompartmentEditPart) {
			return getPrimaryShape().getStackMazeBodyGeneratorDrCompartmentFigure();
		}
		if (editPart instanceof Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorSrCompartmentEditPart) {
			return getPrimaryShape().getStackMazeBodyGeneratorSrCompartmentFigure();
		}
		if (editPart instanceof Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorTrCompartmentEditPart) {
			return getPrimaryShape().getStackMazeBodyGeneratorTrCompartmentFigure();
		}
		if (editPart instanceof Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorErCompartmentEditPart) {
			return getPrimaryShape().getStackMazeBodyGeneratorErCompartmentFigure();
		}
		return getContentPane();
	}

	/**
	* @generated
	*/
	protected NodeFigure createNodePlate() {
		DefaultSizeNodeFigure result = new DefaultSizeNodeFigure(100, 40);
		return result;
	}

	/**
	* Creates figure for this edit part.
	* 
	* Body of this method does not depend on settings in generation model
	* so you may safely remove <i>generated</i> tag and modify it.
	* 
	* @generated
	*/
	protected NodeFigure createNodeFigure() {
		NodeFigure figure = createNodePlate();
		figure.setLayoutManager(new StackLayout());
		IFigure shape = createNodeShape();
		figure.add(shape);
		contentPane = setupContentPane(shape);
		return figure;
	}

	/**
	* Default implementation treats passed figure as content pane.
	* Respects layout one may have set for generated figure.
	* @param nodeShape instance of generated figure class
	* @generated
	*/
	protected IFigure setupContentPane(IFigure nodeShape) {
		if (nodeShape.getLayoutManager() == null) {
			ConstrainedToolbarLayout layout = new ConstrainedToolbarLayout();
			layout.setSpacing(5);
			nodeShape.setLayoutManager(layout);
		}
		return nodeShape; // use nodeShape itself as contentPane
	}

	/**
	* @generated
	*/
	public IFigure getContentPane() {
		if (contentPane != null) {
			return contentPane;
		}
		return super.getContentPane();
	}

	/**
	* @generated
	*/
	protected void setForegroundColor(Color color) {
		if (primaryShape != null) {
			primaryShape.setForegroundColor(color);
		}
	}

	/**
	* @generated
	*/
	protected void setBackgroundColor(Color color) {
		if (primaryShape != null) {
			primaryShape.setBackgroundColor(color);
		}
	}

	/**
	* @generated
	*/
	protected void setLineWidth(int width) {
		if (primaryShape instanceof Shape) {
			((Shape) primaryShape).setLineWidth(width);
		}
	}

	/**
	* @generated
	*/
	protected void setLineType(int style) {
		if (primaryShape instanceof Shape) {
			((Shape) primaryShape).setLineStyle(style);
		}
	}

	/**
	* @generated
	*/
	public EditPart getPrimaryChildEditPart() {
		return getChildBySemanticHint(Maze.diagram.part.MazeVisualIDRegistry
				.getType(Maze.diagram.edit.parts.StackMazeBodyGeneratorType_nameEditPart.VISUAL_ID));
	}

	/**
	* @generated
	*/
	protected void handleNotificationEvent(Notification event) {
		if (event.getNotifier() == getModel()
				&& EcorePackage.eINSTANCE.getEModelElement_EAnnotations().equals(event.getFeature())) {
			handleMajorSemanticChange();
		} else {
			super.handleNotificationEvent(event);
		}
	}

	/**
	 * @generated
	 */
	public class StackMazeBodyGeneratorFigure extends RectangleFigure {

		/**
		 * @generated
		 */
		private WrappingLabel fFigureStackMazeBodyGeneratorLabelFigure;
		/**
		 * @generated
		 */
		private RectangleFigure fStackMazeBodyGeneratorDrCompartmentFigure;
		/**
		 * @generated
		 */
		private RectangleFigure fStackMazeBodyGeneratorSrCompartmentFigure;
		/**
		 * @generated
		 */
		private RectangleFigure fStackMazeBodyGeneratorTrCompartmentFigure;

		/**
		* @generated
		*/
		private RectangleFigure fStackMazeBodyGeneratorErCompartmentFigure;

		/**
			 * @generated
			 */
		public StackMazeBodyGeneratorFigure() {
			this.setBackgroundColor(THIS_BACK);
			this.setPreferredSize(new Dimension(getMapMode().DPtoLP(100), getMapMode().DPtoLP(40)));
			this.setBorder(new MarginBorder(getMapMode().DPtoLP(5), getMapMode().DPtoLP(5), getMapMode().DPtoLP(5),
					getMapMode().DPtoLP(5)));
			createContents();
		}

		/**
		 * @generated
		 */
		private void createContents() {

			fFigureStackMazeBodyGeneratorLabelFigure = new WrappingLabel();

			fFigureStackMazeBodyGeneratorLabelFigure.setText("StackMazeBodyGenerator");
			fFigureStackMazeBodyGeneratorLabelFigure
					.setMaximumSize(new Dimension(getMapMode().DPtoLP(10000), getMapMode().DPtoLP(50)));

			this.add(fFigureStackMazeBodyGeneratorLabelFigure);

			fStackMazeBodyGeneratorDrCompartmentFigure = new RectangleFigure();

			fStackMazeBodyGeneratorDrCompartmentFigure.setOutline(false);

			this.add(fStackMazeBodyGeneratorDrCompartmentFigure);

			fStackMazeBodyGeneratorSrCompartmentFigure = new RectangleFigure();

			fStackMazeBodyGeneratorSrCompartmentFigure.setOutline(false);

			this.add(fStackMazeBodyGeneratorSrCompartmentFigure);

			fStackMazeBodyGeneratorTrCompartmentFigure = new RectangleFigure();

			fStackMazeBodyGeneratorTrCompartmentFigure.setOutline(false);

			this.add(fStackMazeBodyGeneratorTrCompartmentFigure);

			fStackMazeBodyGeneratorErCompartmentFigure = new RectangleFigure();

			fStackMazeBodyGeneratorErCompartmentFigure.setOutline(false);

			this.add(fStackMazeBodyGeneratorErCompartmentFigure);

		}

		/**
		 * @generated
		 */
		public WrappingLabel getFigureStackMazeBodyGeneratorLabelFigure() {
			return fFigureStackMazeBodyGeneratorLabelFigure;
		}

		/**
		 * @generated
		 */
		public RectangleFigure getStackMazeBodyGeneratorDrCompartmentFigure() {
			return fStackMazeBodyGeneratorDrCompartmentFigure;
		}

		/**
		 * @generated
		 */
		public RectangleFigure getStackMazeBodyGeneratorSrCompartmentFigure() {
			return fStackMazeBodyGeneratorSrCompartmentFigure;
		}

		/**
		 * @generated
		 */
		public RectangleFigure getStackMazeBodyGeneratorTrCompartmentFigure() {
			return fStackMazeBodyGeneratorTrCompartmentFigure;
		}

		/**
		* @generated
		*/
		public RectangleFigure getStackMazeBodyGeneratorErCompartmentFigure() {
			return fStackMazeBodyGeneratorErCompartmentFigure;
		}

	}

	/**
	 * @generated
	 */
	static final Color THIS_BACK = new Color(null, 128, 159, 255);

}
