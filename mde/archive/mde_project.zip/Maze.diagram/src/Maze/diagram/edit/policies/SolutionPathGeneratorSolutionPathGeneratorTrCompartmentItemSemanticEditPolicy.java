/*
* 
*/
package Maze.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class SolutionPathGeneratorSolutionPathGeneratorTrCompartmentItemSemanticEditPolicy
		extends Maze.diagram.edit.policies.MazeBaseItemSemanticEditPolicy {

	/**
	* @generated
	*/
	public SolutionPathGeneratorSolutionPathGeneratorTrCompartmentItemSemanticEditPolicy() {
		super(Maze.diagram.providers.MazeElementTypes.SolutionPathGenerator_2003);
	}

	/**
	* @generated
	*/
	protected Command getCreateCommand(CreateElementRequest req) {
		if (Maze.diagram.providers.MazeElementTypes.TurnRate_3005 == req.getElementType()) {
			return getGEFWrapper(new Maze.diagram.edit.commands.TurnRateCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
