/*
 * 
 */
package Maze.diagram.edit.helpers;

/**
 * @generated
 */
public class RowCountEditHelper extends Maze.diagram.edit.helpers.MazeBaseEditHelper {
}
