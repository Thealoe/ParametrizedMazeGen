/*
* 
*/
package Maze.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class RectangleGeneratorRectangleGeneratorCcCompartmentItemSemanticEditPolicy
		extends Maze.diagram.edit.policies.MazeBaseItemSemanticEditPolicy {

	/**
	* @generated
	*/
	public RectangleGeneratorRectangleGeneratorCcCompartmentItemSemanticEditPolicy() {
		super(Maze.diagram.providers.MazeElementTypes.RectangleGenerator_2001);
	}

	/**
	* @generated
	*/
	protected Command getCreateCommand(CreateElementRequest req) {
		if (Maze.diagram.providers.MazeElementTypes.ColumnCount_3002 == req.getElementType()) {
			return getGEFWrapper(new Maze.diagram.edit.commands.ColumnCountCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
