/*
* 
*/
package Maze.diagram.part;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.gmf.tooling.runtime.update.DiagramUpdater;

/**
 * @generated
 */
public class MazeDiagramUpdater {

	/**
	* @generated
	*/
	public static boolean isShortcutOrphaned(View view) {
		return !view.isSetElement() || view.getElement() == null || view.getElement().eIsProxy();
	}

	/**
	* @generated
	*/
	public static List<Maze.diagram.part.MazeNodeDescriptor> getSemanticChildren(View view) {
		switch (Maze.diagram.part.MazeVisualIDRegistry.getVisualID(view)) {
		case Maze.diagram.edit.parts.MazeDiagramEditPart.VISUAL_ID:
			return getMazeDiagram_1000SemanticChildren(view);
		case Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorDrCompartmentEditPart.VISUAL_ID:
			return getStackMazeBodyGeneratorStackMazeBodyGeneratorDrCompartment_7012SemanticChildren(view);
		case Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorSrCompartmentEditPart.VISUAL_ID:
			return getStackMazeBodyGeneratorStackMazeBodyGeneratorSrCompartment_7013SemanticChildren(view);
		case Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorTrCompartmentEditPart.VISUAL_ID:
			return getStackMazeBodyGeneratorStackMazeBodyGeneratorTrCompartment_7014SemanticChildren(view);
		case Maze.diagram.edit.parts.RandomMazeBodyGeneratorRandomMazeBodyGeneratorDrCompartmentEditPart.VISUAL_ID:
			return getRandomMazeBodyGeneratorRandomMazeBodyGeneratorDrCompartment_7015SemanticChildren(view);
		case Maze.diagram.edit.parts.RandomMazeBodyGeneratorRandomMazeBodyGeneratorSrCompartmentEditPart.VISUAL_ID:
			return getRandomMazeBodyGeneratorRandomMazeBodyGeneratorSrCompartment_7016SemanticChildren(view);
		case Maze.diagram.edit.parts.RandomMazeBodyGeneratorRandomMazeBodyGeneratorTrCompartmentEditPart.VISUAL_ID:
			return getRandomMazeBodyGeneratorRandomMazeBodyGeneratorTrCompartment_7017SemanticChildren(view);
		case Maze.diagram.edit.parts.RectangleGeneratorRectangleGeneratorRcCompartmentEditPart.VISUAL_ID:
			return getRectangleGeneratorRectangleGeneratorRcCompartment_7007SemanticChildren(view);
		case Maze.diagram.edit.parts.RectangleGeneratorRectangleGeneratorCcCompartmentEditPart.VISUAL_ID:
			return getRectangleGeneratorRectangleGeneratorCcCompartment_7008SemanticChildren(view);
		case Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorTrCompartmentEditPart.VISUAL_ID:
			return getSolutionPathGeneratorSolutionPathGeneratorTrCompartment_7009SemanticChildren(view);
		case Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorSrCompartmentEditPart.VISUAL_ID:
			return getSolutionPathGeneratorSolutionPathGeneratorSrCompartment_7010SemanticChildren(view);
		case Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorDrCompartmentEditPart.VISUAL_ID:
			return getSolutionPathGeneratorSolutionPathGeneratorDrCompartment_7011SemanticChildren(view);
		}
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static List<Maze.diagram.part.MazeNodeDescriptor> getMazeDiagram_1000SemanticChildren(View view) {
		if (!view.isSetElement()) {
			return Collections.emptyList();
		}
		Maze.MazeDiagram modelElement = (Maze.MazeDiagram) view.getElement();
		LinkedList<Maze.diagram.part.MazeNodeDescriptor> result = new LinkedList<Maze.diagram.part.MazeNodeDescriptor>();
		{
			Maze.MazeBodyGenerator childElement = modelElement.getMazeBodyGen();
			int visualID = Maze.diagram.part.MazeVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == Maze.diagram.edit.parts.StackMazeBodyGeneratorEditPart.VISUAL_ID) {
				result.add(new Maze.diagram.part.MazeNodeDescriptor(childElement, visualID));
			}
			if (visualID == Maze.diagram.edit.parts.RandomMazeBodyGeneratorEditPart.VISUAL_ID) {
				result.add(new Maze.diagram.part.MazeNodeDescriptor(childElement, visualID));
			}
		}
		{
			Maze.RectangleGenerator childElement = modelElement.getRectangleGen();
			int visualID = Maze.diagram.part.MazeVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == Maze.diagram.edit.parts.RectangleGeneratorEditPart.VISUAL_ID) {
				result.add(new Maze.diagram.part.MazeNodeDescriptor(childElement, visualID));
			}
		}
		{
			Maze.SolutionPathGenerator childElement = modelElement.getSolutionPathGen();
			int visualID = Maze.diagram.part.MazeVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == Maze.diagram.edit.parts.SolutionPathGeneratorEditPart.VISUAL_ID) {
				result.add(new Maze.diagram.part.MazeNodeDescriptor(childElement, visualID));
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<Maze.diagram.part.MazeNodeDescriptor> getStackMazeBodyGeneratorStackMazeBodyGeneratorDrCompartment_7012SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Maze.StackMazeBodyGenerator modelElement = (Maze.StackMazeBodyGenerator) containerView.getElement();
		LinkedList<Maze.diagram.part.MazeNodeDescriptor> result = new LinkedList<Maze.diagram.part.MazeNodeDescriptor>();
		{
			Maze.DecisionsRate childElement = modelElement.getDr();
			int visualID = Maze.diagram.part.MazeVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == Maze.diagram.edit.parts.DecisionsRateEditPart.VISUAL_ID) {
				result.add(new Maze.diagram.part.MazeNodeDescriptor(childElement, visualID));
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<Maze.diagram.part.MazeNodeDescriptor> getStackMazeBodyGeneratorStackMazeBodyGeneratorSrCompartment_7013SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Maze.StackMazeBodyGenerator modelElement = (Maze.StackMazeBodyGenerator) containerView.getElement();
		LinkedList<Maze.diagram.part.MazeNodeDescriptor> result = new LinkedList<Maze.diagram.part.MazeNodeDescriptor>();
		{
			Maze.StraightRate childElement = modelElement.getSr();
			int visualID = Maze.diagram.part.MazeVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == Maze.diagram.edit.parts.StraightRateEditPart.VISUAL_ID) {
				result.add(new Maze.diagram.part.MazeNodeDescriptor(childElement, visualID));
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<Maze.diagram.part.MazeNodeDescriptor> getStackMazeBodyGeneratorStackMazeBodyGeneratorTrCompartment_7014SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Maze.StackMazeBodyGenerator modelElement = (Maze.StackMazeBodyGenerator) containerView.getElement();
		LinkedList<Maze.diagram.part.MazeNodeDescriptor> result = new LinkedList<Maze.diagram.part.MazeNodeDescriptor>();
		{
			Maze.TurnRate childElement = modelElement.getTr();
			int visualID = Maze.diagram.part.MazeVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == Maze.diagram.edit.parts.TurnRateEditPart.VISUAL_ID) {
				result.add(new Maze.diagram.part.MazeNodeDescriptor(childElement, visualID));
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<Maze.diagram.part.MazeNodeDescriptor> getRandomMazeBodyGeneratorRandomMazeBodyGeneratorDrCompartment_7015SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Maze.RandomMazeBodyGenerator modelElement = (Maze.RandomMazeBodyGenerator) containerView.getElement();
		LinkedList<Maze.diagram.part.MazeNodeDescriptor> result = new LinkedList<Maze.diagram.part.MazeNodeDescriptor>();
		{
			Maze.DecisionsRate childElement = modelElement.getDr();
			int visualID = Maze.diagram.part.MazeVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == Maze.diagram.edit.parts.DecisionsRateEditPart.VISUAL_ID) {
				result.add(new Maze.diagram.part.MazeNodeDescriptor(childElement, visualID));
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<Maze.diagram.part.MazeNodeDescriptor> getRandomMazeBodyGeneratorRandomMazeBodyGeneratorSrCompartment_7016SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Maze.RandomMazeBodyGenerator modelElement = (Maze.RandomMazeBodyGenerator) containerView.getElement();
		LinkedList<Maze.diagram.part.MazeNodeDescriptor> result = new LinkedList<Maze.diagram.part.MazeNodeDescriptor>();
		{
			Maze.StraightRate childElement = modelElement.getSr();
			int visualID = Maze.diagram.part.MazeVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == Maze.diagram.edit.parts.StraightRateEditPart.VISUAL_ID) {
				result.add(new Maze.diagram.part.MazeNodeDescriptor(childElement, visualID));
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<Maze.diagram.part.MazeNodeDescriptor> getRandomMazeBodyGeneratorRandomMazeBodyGeneratorTrCompartment_7017SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Maze.RandomMazeBodyGenerator modelElement = (Maze.RandomMazeBodyGenerator) containerView.getElement();
		LinkedList<Maze.diagram.part.MazeNodeDescriptor> result = new LinkedList<Maze.diagram.part.MazeNodeDescriptor>();
		{
			Maze.TurnRate childElement = modelElement.getTr();
			int visualID = Maze.diagram.part.MazeVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == Maze.diagram.edit.parts.TurnRateEditPart.VISUAL_ID) {
				result.add(new Maze.diagram.part.MazeNodeDescriptor(childElement, visualID));
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<Maze.diagram.part.MazeNodeDescriptor> getRectangleGeneratorRectangleGeneratorRcCompartment_7007SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Maze.RectangleGenerator modelElement = (Maze.RectangleGenerator) containerView.getElement();
		LinkedList<Maze.diagram.part.MazeNodeDescriptor> result = new LinkedList<Maze.diagram.part.MazeNodeDescriptor>();
		{
			Maze.RowCount childElement = modelElement.getRc();
			int visualID = Maze.diagram.part.MazeVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == Maze.diagram.edit.parts.RowCountEditPart.VISUAL_ID) {
				result.add(new Maze.diagram.part.MazeNodeDescriptor(childElement, visualID));
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<Maze.diagram.part.MazeNodeDescriptor> getRectangleGeneratorRectangleGeneratorCcCompartment_7008SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Maze.RectangleGenerator modelElement = (Maze.RectangleGenerator) containerView.getElement();
		LinkedList<Maze.diagram.part.MazeNodeDescriptor> result = new LinkedList<Maze.diagram.part.MazeNodeDescriptor>();
		{
			Maze.ColumnCount childElement = modelElement.getCc();
			int visualID = Maze.diagram.part.MazeVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == Maze.diagram.edit.parts.ColumnCountEditPart.VISUAL_ID) {
				result.add(new Maze.diagram.part.MazeNodeDescriptor(childElement, visualID));
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<Maze.diagram.part.MazeNodeDescriptor> getSolutionPathGeneratorSolutionPathGeneratorTrCompartment_7009SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Maze.SolutionPathGenerator modelElement = (Maze.SolutionPathGenerator) containerView.getElement();
		LinkedList<Maze.diagram.part.MazeNodeDescriptor> result = new LinkedList<Maze.diagram.part.MazeNodeDescriptor>();
		{
			Maze.TurnRate childElement = modelElement.getTr();
			int visualID = Maze.diagram.part.MazeVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == Maze.diagram.edit.parts.TurnRate2EditPart.VISUAL_ID) {
				result.add(new Maze.diagram.part.MazeNodeDescriptor(childElement, visualID));
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<Maze.diagram.part.MazeNodeDescriptor> getSolutionPathGeneratorSolutionPathGeneratorSrCompartment_7010SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Maze.SolutionPathGenerator modelElement = (Maze.SolutionPathGenerator) containerView.getElement();
		LinkedList<Maze.diagram.part.MazeNodeDescriptor> result = new LinkedList<Maze.diagram.part.MazeNodeDescriptor>();
		{
			Maze.StraightRate childElement = modelElement.getSr();
			int visualID = Maze.diagram.part.MazeVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == Maze.diagram.edit.parts.StraightRate2EditPart.VISUAL_ID) {
				result.add(new Maze.diagram.part.MazeNodeDescriptor(childElement, visualID));
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<Maze.diagram.part.MazeNodeDescriptor> getSolutionPathGeneratorSolutionPathGeneratorDrCompartment_7011SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Maze.SolutionPathGenerator modelElement = (Maze.SolutionPathGenerator) containerView.getElement();
		LinkedList<Maze.diagram.part.MazeNodeDescriptor> result = new LinkedList<Maze.diagram.part.MazeNodeDescriptor>();
		{
			Maze.DecisionsRate childElement = modelElement.getDr();
			int visualID = Maze.diagram.part.MazeVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == Maze.diagram.edit.parts.DecisionsRate2EditPart.VISUAL_ID) {
				result.add(new Maze.diagram.part.MazeNodeDescriptor(childElement, visualID));
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<Maze.diagram.part.MazeLinkDescriptor> getContainedLinks(View view) {
		switch (Maze.diagram.part.MazeVisualIDRegistry.getVisualID(view)) {
		case Maze.diagram.edit.parts.MazeDiagramEditPart.VISUAL_ID:
			return getMazeDiagram_1000ContainedLinks(view);
		case Maze.diagram.edit.parts.StackMazeBodyGeneratorEditPart.VISUAL_ID:
			return getStackMazeBodyGenerator_2005ContainedLinks(view);
		case Maze.diagram.edit.parts.RandomMazeBodyGeneratorEditPart.VISUAL_ID:
			return getRandomMazeBodyGenerator_2006ContainedLinks(view);
		case Maze.diagram.edit.parts.RectangleGeneratorEditPart.VISUAL_ID:
			return getRectangleGenerator_2003ContainedLinks(view);
		case Maze.diagram.edit.parts.SolutionPathGeneratorEditPart.VISUAL_ID:
			return getSolutionPathGenerator_2004ContainedLinks(view);
		case Maze.diagram.edit.parts.DecisionsRateEditPart.VISUAL_ID:
			return getDecisionsRate_3001ContainedLinks(view);
		case Maze.diagram.edit.parts.StraightRateEditPart.VISUAL_ID:
			return getStraightRate_3002ContainedLinks(view);
		case Maze.diagram.edit.parts.TurnRateEditPart.VISUAL_ID:
			return getTurnRate_3003ContainedLinks(view);
		case Maze.diagram.edit.parts.RowCountEditPart.VISUAL_ID:
			return getRowCount_3004ContainedLinks(view);
		case Maze.diagram.edit.parts.ColumnCountEditPart.VISUAL_ID:
			return getColumnCount_3005ContainedLinks(view);
		case Maze.diagram.edit.parts.TurnRate2EditPart.VISUAL_ID:
			return getTurnRate_3006ContainedLinks(view);
		case Maze.diagram.edit.parts.StraightRate2EditPart.VISUAL_ID:
			return getStraightRate_3007ContainedLinks(view);
		case Maze.diagram.edit.parts.DecisionsRate2EditPart.VISUAL_ID:
			return getDecisionsRate_3008ContainedLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static List<Maze.diagram.part.MazeLinkDescriptor> getIncomingLinks(View view) {
		switch (Maze.diagram.part.MazeVisualIDRegistry.getVisualID(view)) {
		case Maze.diagram.edit.parts.StackMazeBodyGeneratorEditPart.VISUAL_ID:
			return getStackMazeBodyGenerator_2005IncomingLinks(view);
		case Maze.diagram.edit.parts.RandomMazeBodyGeneratorEditPart.VISUAL_ID:
			return getRandomMazeBodyGenerator_2006IncomingLinks(view);
		case Maze.diagram.edit.parts.RectangleGeneratorEditPart.VISUAL_ID:
			return getRectangleGenerator_2003IncomingLinks(view);
		case Maze.diagram.edit.parts.SolutionPathGeneratorEditPart.VISUAL_ID:
			return getSolutionPathGenerator_2004IncomingLinks(view);
		case Maze.diagram.edit.parts.DecisionsRateEditPart.VISUAL_ID:
			return getDecisionsRate_3001IncomingLinks(view);
		case Maze.diagram.edit.parts.StraightRateEditPart.VISUAL_ID:
			return getStraightRate_3002IncomingLinks(view);
		case Maze.diagram.edit.parts.TurnRateEditPart.VISUAL_ID:
			return getTurnRate_3003IncomingLinks(view);
		case Maze.diagram.edit.parts.RowCountEditPart.VISUAL_ID:
			return getRowCount_3004IncomingLinks(view);
		case Maze.diagram.edit.parts.ColumnCountEditPart.VISUAL_ID:
			return getColumnCount_3005IncomingLinks(view);
		case Maze.diagram.edit.parts.TurnRate2EditPart.VISUAL_ID:
			return getTurnRate_3006IncomingLinks(view);
		case Maze.diagram.edit.parts.StraightRate2EditPart.VISUAL_ID:
			return getStraightRate_3007IncomingLinks(view);
		case Maze.diagram.edit.parts.DecisionsRate2EditPart.VISUAL_ID:
			return getDecisionsRate_3008IncomingLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static List<Maze.diagram.part.MazeLinkDescriptor> getOutgoingLinks(View view) {
		switch (Maze.diagram.part.MazeVisualIDRegistry.getVisualID(view)) {
		case Maze.diagram.edit.parts.StackMazeBodyGeneratorEditPart.VISUAL_ID:
			return getStackMazeBodyGenerator_2005OutgoingLinks(view);
		case Maze.diagram.edit.parts.RandomMazeBodyGeneratorEditPart.VISUAL_ID:
			return getRandomMazeBodyGenerator_2006OutgoingLinks(view);
		case Maze.diagram.edit.parts.RectangleGeneratorEditPart.VISUAL_ID:
			return getRectangleGenerator_2003OutgoingLinks(view);
		case Maze.diagram.edit.parts.SolutionPathGeneratorEditPart.VISUAL_ID:
			return getSolutionPathGenerator_2004OutgoingLinks(view);
		case Maze.diagram.edit.parts.DecisionsRateEditPart.VISUAL_ID:
			return getDecisionsRate_3001OutgoingLinks(view);
		case Maze.diagram.edit.parts.StraightRateEditPart.VISUAL_ID:
			return getStraightRate_3002OutgoingLinks(view);
		case Maze.diagram.edit.parts.TurnRateEditPart.VISUAL_ID:
			return getTurnRate_3003OutgoingLinks(view);
		case Maze.diagram.edit.parts.RowCountEditPart.VISUAL_ID:
			return getRowCount_3004OutgoingLinks(view);
		case Maze.diagram.edit.parts.ColumnCountEditPart.VISUAL_ID:
			return getColumnCount_3005OutgoingLinks(view);
		case Maze.diagram.edit.parts.TurnRate2EditPart.VISUAL_ID:
			return getTurnRate_3006OutgoingLinks(view);
		case Maze.diagram.edit.parts.StraightRate2EditPart.VISUAL_ID:
			return getStraightRate_3007OutgoingLinks(view);
		case Maze.diagram.edit.parts.DecisionsRate2EditPart.VISUAL_ID:
			return getDecisionsRate_3008OutgoingLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getMazeDiagram_1000ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getStackMazeBodyGenerator_2005ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getRandomMazeBodyGenerator_2006ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getRectangleGenerator_2003ContainedLinks(View view) {
		Maze.RectangleGenerator modelElement = (Maze.RectangleGenerator) view.getElement();
		LinkedList<Maze.diagram.part.MazeLinkDescriptor> result = new LinkedList<Maze.diagram.part.MazeLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_RectangleGenerator_Spg_4001(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getSolutionPathGenerator_2004ContainedLinks(View view) {
		Maze.SolutionPathGenerator modelElement = (Maze.SolutionPathGenerator) view.getElement();
		LinkedList<Maze.diagram.part.MazeLinkDescriptor> result = new LinkedList<Maze.diagram.part.MazeLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_SolutionPathGenerator_Mbg_4002(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getDecisionsRate_3001ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getStraightRate_3002ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getTurnRate_3003ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getRowCount_3004ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getColumnCount_3005ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getTurnRate_3006ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getStraightRate_3007ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getDecisionsRate_3008ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getStackMazeBodyGenerator_2005IncomingLinks(View view) {
		Maze.StackMazeBodyGenerator modelElement = (Maze.StackMazeBodyGenerator) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<Maze.diagram.part.MazeLinkDescriptor> result = new LinkedList<Maze.diagram.part.MazeLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_SolutionPathGenerator_Mbg_4002(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getRandomMazeBodyGenerator_2006IncomingLinks(View view) {
		Maze.RandomMazeBodyGenerator modelElement = (Maze.RandomMazeBodyGenerator) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<Maze.diagram.part.MazeLinkDescriptor> result = new LinkedList<Maze.diagram.part.MazeLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_SolutionPathGenerator_Mbg_4002(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getRectangleGenerator_2003IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getSolutionPathGenerator_2004IncomingLinks(View view) {
		Maze.SolutionPathGenerator modelElement = (Maze.SolutionPathGenerator) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<Maze.diagram.part.MazeLinkDescriptor> result = new LinkedList<Maze.diagram.part.MazeLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_RectangleGenerator_Spg_4001(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getDecisionsRate_3001IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getStraightRate_3002IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getTurnRate_3003IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getRowCount_3004IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getColumnCount_3005IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getTurnRate_3006IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getStraightRate_3007IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getDecisionsRate_3008IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getStackMazeBodyGenerator_2005OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getRandomMazeBodyGenerator_2006OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getRectangleGenerator_2003OutgoingLinks(View view) {
		Maze.RectangleGenerator modelElement = (Maze.RectangleGenerator) view.getElement();
		LinkedList<Maze.diagram.part.MazeLinkDescriptor> result = new LinkedList<Maze.diagram.part.MazeLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_RectangleGenerator_Spg_4001(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getSolutionPathGenerator_2004OutgoingLinks(View view) {
		Maze.SolutionPathGenerator modelElement = (Maze.SolutionPathGenerator) view.getElement();
		LinkedList<Maze.diagram.part.MazeLinkDescriptor> result = new LinkedList<Maze.diagram.part.MazeLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_SolutionPathGenerator_Mbg_4002(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getDecisionsRate_3001OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getStraightRate_3002OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getTurnRate_3003OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getRowCount_3004OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getColumnCount_3005OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getTurnRate_3006OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getStraightRate_3007OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<Maze.diagram.part.MazeLinkDescriptor> getDecisionsRate_3008OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	private static Collection<Maze.diagram.part.MazeLinkDescriptor> getIncomingFeatureModelFacetLinks_RectangleGenerator_Spg_4001(
			Maze.SolutionPathGenerator target, Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<Maze.diagram.part.MazeLinkDescriptor> result = new LinkedList<Maze.diagram.part.MazeLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == Maze.MazePackage.eINSTANCE.getRectangleGenerator_Spg()) {
				result.add(new Maze.diagram.part.MazeLinkDescriptor(setting.getEObject(), target,
						Maze.diagram.providers.MazeElementTypes.RectangleGeneratorSpg_4001,
						Maze.diagram.edit.parts.RectangleGeneratorSpgEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<Maze.diagram.part.MazeLinkDescriptor> getIncomingFeatureModelFacetLinks_SolutionPathGenerator_Mbg_4002(
			Maze.MazeBodyGenerator target, Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<Maze.diagram.part.MazeLinkDescriptor> result = new LinkedList<Maze.diagram.part.MazeLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == Maze.MazePackage.eINSTANCE.getSolutionPathGenerator_Mbg()) {
				result.add(new Maze.diagram.part.MazeLinkDescriptor(setting.getEObject(), target,
						Maze.diagram.providers.MazeElementTypes.SolutionPathGeneratorMbg_4002,
						Maze.diagram.edit.parts.SolutionPathGeneratorMbgEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	private static Collection<Maze.diagram.part.MazeLinkDescriptor> getOutgoingFeatureModelFacetLinks_RectangleGenerator_Spg_4001(
			Maze.RectangleGenerator source) {
		LinkedList<Maze.diagram.part.MazeLinkDescriptor> result = new LinkedList<Maze.diagram.part.MazeLinkDescriptor>();
		Maze.SolutionPathGenerator destination = source.getSpg();
		if (destination == null) {
			return result;
		}
		result.add(new Maze.diagram.part.MazeLinkDescriptor(source, destination,
				Maze.diagram.providers.MazeElementTypes.RectangleGeneratorSpg_4001,
				Maze.diagram.edit.parts.RectangleGeneratorSpgEditPart.VISUAL_ID));
		return result;
	}

	/**
	* @generated
	*/
	private static Collection<Maze.diagram.part.MazeLinkDescriptor> getOutgoingFeatureModelFacetLinks_SolutionPathGenerator_Mbg_4002(
			Maze.SolutionPathGenerator source) {
		LinkedList<Maze.diagram.part.MazeLinkDescriptor> result = new LinkedList<Maze.diagram.part.MazeLinkDescriptor>();
		Maze.MazeBodyGenerator destination = source.getMbg();
		if (destination == null) {
			return result;
		}
		result.add(new Maze.diagram.part.MazeLinkDescriptor(source, destination,
				Maze.diagram.providers.MazeElementTypes.SolutionPathGeneratorMbg_4002,
				Maze.diagram.edit.parts.SolutionPathGeneratorMbgEditPart.VISUAL_ID));
		return result;
	}

	/**
	* @generated
	*/
	public static final DiagramUpdater TYPED_INSTANCE = new DiagramUpdater() {
		/**
		* @generated
		*/
		@Override

		public List<Maze.diagram.part.MazeNodeDescriptor> getSemanticChildren(View view) {
			return MazeDiagramUpdater.getSemanticChildren(view);
		}

		/**
		* @generated
		*/
		@Override

		public List<Maze.diagram.part.MazeLinkDescriptor> getContainedLinks(View view) {
			return MazeDiagramUpdater.getContainedLinks(view);
		}

		/**
		* @generated
		*/
		@Override

		public List<Maze.diagram.part.MazeLinkDescriptor> getIncomingLinks(View view) {
			return MazeDiagramUpdater.getIncomingLinks(view);
		}

		/**
		* @generated
		*/
		@Override

		public List<Maze.diagram.part.MazeLinkDescriptor> getOutgoingLinks(View view) {
			return MazeDiagramUpdater.getOutgoingLinks(view);
		}
	};

}
