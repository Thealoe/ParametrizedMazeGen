
/*
 * 
 */
package Maze.diagram.part;

import java.util.ArrayList;
import java.util.Collections;

import org.eclipse.gef.palette.PaletteContainer;
import org.eclipse.gef.palette.PaletteDrawer;
import org.eclipse.gef.palette.PaletteRoot;
import org.eclipse.gef.palette.ToolEntry;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.tooling.runtime.part.DefaultLinkToolEntry;
import org.eclipse.gmf.tooling.runtime.part.DefaultNodeToolEntry;

/**
 * @generated
 */
public class MazePaletteFactory {

	/**
	* @generated
	*/
	public void fillPalette(PaletteRoot paletteRoot) {
		paletteRoot.add(createObjects1Group());
		paletteRoot.add(createConnections2Group());
	}

	/**
	* Creates "Objects" palette tool group
	* @generated
	*/
	private PaletteContainer createObjects1Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(Maze.diagram.part.Messages.Objects1Group_title);
		paletteContainer.setId("createObjects1Group"); //$NON-NLS-1$
		paletteContainer.add(createColumnCount1CreationTool());
		paletteContainer.add(createDecisionsRate2CreationTool());
		paletteContainer.add(createRandomMazeBodyGenerator3CreationTool());
		paletteContainer.add(createRectangleGenerator4CreationTool());
		paletteContainer.add(createRowCount5CreationTool());
		paletteContainer.add(createSolutionPathGenerator6CreationTool());
		paletteContainer.add(createStackMazeBodyGenerator7CreationTool());
		paletteContainer.add(createStraightRate8CreationTool());
		paletteContainer.add(createTurnRate9CreationTool());
		return paletteContainer;
	}

	/**
	* Creates "Connections" palette tool group
	* @generated
	*/
	private PaletteContainer createConnections2Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(Maze.diagram.part.Messages.Connections2Group_title);
		paletteContainer.setId("createConnections2Group"); //$NON-NLS-1$
		paletteContainer.add(createMbg1CreationTool());
		paletteContainer.add(createSpg2CreationTool());
		return paletteContainer;
	}

	/**
	* @generated
	*/
	private ToolEntry createColumnCount1CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(Maze.diagram.part.Messages.ColumnCount1CreationTool_title,
				Maze.diagram.part.Messages.ColumnCount1CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.ColumnCount_3005));
		entry.setId("createColumnCount1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.ColumnCount_3005));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createDecisionsRate2CreationTool() {
		ArrayList<IElementType> types = new ArrayList<IElementType>(2);
		types.add(Maze.diagram.providers.MazeElementTypes.DecisionsRate_3001);
		types.add(Maze.diagram.providers.MazeElementTypes.DecisionsRate_3008);
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				Maze.diagram.part.Messages.DecisionsRate2CreationTool_title,
				Maze.diagram.part.Messages.DecisionsRate2CreationTool_desc, types);
		entry.setId("createDecisionsRate2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.DecisionsRate_3001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createRandomMazeBodyGenerator3CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				Maze.diagram.part.Messages.RandomMazeBodyGenerator3CreationTool_title,
				Maze.diagram.part.Messages.RandomMazeBodyGenerator3CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.RandomMazeBodyGenerator_2006));
		entry.setId("createRandomMazeBodyGenerator3CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.RandomMazeBodyGenerator_2006));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createRectangleGenerator4CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				Maze.diagram.part.Messages.RectangleGenerator4CreationTool_title,
				Maze.diagram.part.Messages.RectangleGenerator4CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.RectangleGenerator_2003));
		entry.setId("createRectangleGenerator4CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.RectangleGenerator_2003));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createRowCount5CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(Maze.diagram.part.Messages.RowCount5CreationTool_title,
				Maze.diagram.part.Messages.RowCount5CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.RowCount_3004));
		entry.setId("createRowCount5CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.RowCount_3004));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createSolutionPathGenerator6CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				Maze.diagram.part.Messages.SolutionPathGenerator6CreationTool_title,
				Maze.diagram.part.Messages.SolutionPathGenerator6CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.SolutionPathGenerator_2004));
		entry.setId("createSolutionPathGenerator6CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.SolutionPathGenerator_2004));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createStackMazeBodyGenerator7CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				Maze.diagram.part.Messages.StackMazeBodyGenerator7CreationTool_title,
				Maze.diagram.part.Messages.StackMazeBodyGenerator7CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.StackMazeBodyGenerator_2005));
		entry.setId("createStackMazeBodyGenerator7CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.StackMazeBodyGenerator_2005));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createStraightRate8CreationTool() {
		ArrayList<IElementType> types = new ArrayList<IElementType>(2);
		types.add(Maze.diagram.providers.MazeElementTypes.StraightRate_3002);
		types.add(Maze.diagram.providers.MazeElementTypes.StraightRate_3007);
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				Maze.diagram.part.Messages.StraightRate8CreationTool_title,
				Maze.diagram.part.Messages.StraightRate8CreationTool_desc, types);
		entry.setId("createStraightRate8CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.StraightRate_3002));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createTurnRate9CreationTool() {
		ArrayList<IElementType> types = new ArrayList<IElementType>(2);
		types.add(Maze.diagram.providers.MazeElementTypes.TurnRate_3003);
		types.add(Maze.diagram.providers.MazeElementTypes.TurnRate_3006);
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(Maze.diagram.part.Messages.TurnRate9CreationTool_title,
				Maze.diagram.part.Messages.TurnRate9CreationTool_desc, types);
		entry.setId("createTurnRate9CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.TurnRate_3003));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createMbg1CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(Maze.diagram.part.Messages.Mbg1CreationTool_title,
				Maze.diagram.part.Messages.Mbg1CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.SolutionPathGeneratorMbg_4002));
		entry.setId("createMbg1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.SolutionPathGeneratorMbg_4002));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createSpg2CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(Maze.diagram.part.Messages.Spg2CreationTool_title,
				Maze.diagram.part.Messages.Spg2CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.RectangleGeneratorSpg_4001));
		entry.setId("createSpg2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.RectangleGeneratorSpg_4001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

}
