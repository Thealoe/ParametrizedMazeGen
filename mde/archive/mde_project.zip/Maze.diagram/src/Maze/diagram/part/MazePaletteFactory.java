
/*
 * 
 */
package Maze.diagram.part;

import java.util.ArrayList;
import java.util.Collections;

import org.eclipse.gef.palette.PaletteContainer;
import org.eclipse.gef.palette.PaletteDrawer;
import org.eclipse.gef.palette.PaletteRoot;
import org.eclipse.gef.palette.ToolEntry;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.tooling.runtime.part.DefaultLinkToolEntry;
import org.eclipse.gmf.tooling.runtime.part.DefaultNodeToolEntry;

/**
 * @generated
 */
public class MazePaletteFactory {

	/**
	* @generated
	*/
	public void fillPalette(PaletteRoot paletteRoot) {
		paletteRoot.add(createObjects1Group());
		paletteRoot.add(createConnections2Group());
	}

	/**
	* Creates "Objects" palette tool group
	* @generated
	*/
	private PaletteContainer createObjects1Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(Maze.diagram.part.Messages.Objects1Group_title);
		paletteContainer.setId("createObjects1Group"); //$NON-NLS-1$
		paletteContainer.add(createColumnCount1CreationTool());
		paletteContainer.add(createDecisionsRate2CreationTool());
		paletteContainer.add(createEndPoint3CreationTool());
		paletteContainer.add(createEndRate4CreationTool());
		paletteContainer.add(createRandomMazeBodyGenerator5CreationTool());
		paletteContainer.add(createRectangleGenerator6CreationTool());
		paletteContainer.add(createRowCount7CreationTool());
		paletteContainer.add(createSolutionPathGenerator8CreationTool());
		paletteContainer.add(createStackMazeBodyGenerator9CreationTool());
		paletteContainer.add(createStartPoint10CreationTool());
		paletteContainer.add(createStraightRate11CreationTool());
		paletteContainer.add(createTurnRate12CreationTool());
		return paletteContainer;
	}

	/**
	* Creates "Connections" palette tool group
	* @generated
	*/
	private PaletteContainer createConnections2Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(Maze.diagram.part.Messages.Connections2Group_title);
		paletteContainer.setId("createConnections2Group"); //$NON-NLS-1$
		paletteContainer.add(createMbg1CreationTool());
		paletteContainer.add(createSpg2CreationTool());
		return paletteContainer;
	}

	/**
	* @generated
	*/
	private ToolEntry createColumnCount1CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(Maze.diagram.part.Messages.ColumnCount1CreationTool_title,
				Maze.diagram.part.Messages.ColumnCount1CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.ColumnCount_3005));
		entry.setId("createColumnCount1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.ColumnCount_3005));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createDecisionsRate2CreationTool() {
		ArrayList<IElementType> types = new ArrayList<IElementType>(2);
		types.add(Maze.diagram.providers.MazeElementTypes.DecisionsRate_3001);
		types.add(Maze.diagram.providers.MazeElementTypes.DecisionsRate_3008);
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				Maze.diagram.part.Messages.DecisionsRate2CreationTool_title,
				Maze.diagram.part.Messages.DecisionsRate2CreationTool_desc, types);
		entry.setId("createDecisionsRate2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.DecisionsRate_3001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createEndPoint3CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(Maze.diagram.part.Messages.EndPoint3CreationTool_title,
				Maze.diagram.part.Messages.EndPoint3CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.EndPoint_3011));
		entry.setId("createEndPoint3CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.EndPoint_3011));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createEndRate4CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(Maze.diagram.part.Messages.EndRate4CreationTool_title,
				Maze.diagram.part.Messages.EndRate4CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.EndRate_3009));
		entry.setId("createEndRate4CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.EndRate_3009));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createRandomMazeBodyGenerator5CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				Maze.diagram.part.Messages.RandomMazeBodyGenerator5CreationTool_title,
				Maze.diagram.part.Messages.RandomMazeBodyGenerator5CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.RandomMazeBodyGenerator_2006));
		entry.setId("createRandomMazeBodyGenerator5CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.RandomMazeBodyGenerator_2006));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createRectangleGenerator6CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				Maze.diagram.part.Messages.RectangleGenerator6CreationTool_title,
				Maze.diagram.part.Messages.RectangleGenerator6CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.RectangleGenerator_2003));
		entry.setId("createRectangleGenerator6CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.RectangleGenerator_2003));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createRowCount7CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(Maze.diagram.part.Messages.RowCount7CreationTool_title,
				Maze.diagram.part.Messages.RowCount7CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.RowCount_3004));
		entry.setId("createRowCount7CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.RowCount_3004));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createSolutionPathGenerator8CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				Maze.diagram.part.Messages.SolutionPathGenerator8CreationTool_title,
				Maze.diagram.part.Messages.SolutionPathGenerator8CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.SolutionPathGenerator_2004));
		entry.setId("createSolutionPathGenerator8CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.SolutionPathGenerator_2004));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createStackMazeBodyGenerator9CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				Maze.diagram.part.Messages.StackMazeBodyGenerator9CreationTool_title,
				Maze.diagram.part.Messages.StackMazeBodyGenerator9CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.StackMazeBodyGenerator_2005));
		entry.setId("createStackMazeBodyGenerator9CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.StackMazeBodyGenerator_2005));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createStartPoint10CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(Maze.diagram.part.Messages.StartPoint10CreationTool_title,
				Maze.diagram.part.Messages.StartPoint10CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.StartPoint_3010));
		entry.setId("createStartPoint10CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.StartPoint_3010));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createStraightRate11CreationTool() {
		ArrayList<IElementType> types = new ArrayList<IElementType>(2);
		types.add(Maze.diagram.providers.MazeElementTypes.StraightRate_3002);
		types.add(Maze.diagram.providers.MazeElementTypes.StraightRate_3007);
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				Maze.diagram.part.Messages.StraightRate11CreationTool_title,
				Maze.diagram.part.Messages.StraightRate11CreationTool_desc, types);
		entry.setId("createStraightRate11CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.StraightRate_3002));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createTurnRate12CreationTool() {
		ArrayList<IElementType> types = new ArrayList<IElementType>(2);
		types.add(Maze.diagram.providers.MazeElementTypes.TurnRate_3003);
		types.add(Maze.diagram.providers.MazeElementTypes.TurnRate_3006);
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(Maze.diagram.part.Messages.TurnRate12CreationTool_title,
				Maze.diagram.part.Messages.TurnRate12CreationTool_desc, types);
		entry.setId("createTurnRate12CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.TurnRate_3003));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createMbg1CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(Maze.diagram.part.Messages.Mbg1CreationTool_title,
				Maze.diagram.part.Messages.Mbg1CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.SolutionPathGeneratorMbg_4002));
		entry.setId("createMbg1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.SolutionPathGeneratorMbg_4002));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createSpg2CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(Maze.diagram.part.Messages.Spg2CreationTool_title,
				Maze.diagram.part.Messages.Spg2CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.RectangleGeneratorSpg_4001));
		entry.setId("createSpg2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.RectangleGeneratorSpg_4001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

}
