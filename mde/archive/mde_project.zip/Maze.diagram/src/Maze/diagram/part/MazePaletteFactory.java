
/*
 * 
 */
package Maze.diagram.part;

import java.util.ArrayList;
import java.util.Collections;

import org.eclipse.gef.palette.PaletteContainer;
import org.eclipse.gef.palette.PaletteDrawer;
import org.eclipse.gef.palette.PaletteRoot;
import org.eclipse.gef.palette.ToolEntry;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.tooling.runtime.part.DefaultLinkToolEntry;
import org.eclipse.gmf.tooling.runtime.part.DefaultNodeToolEntry;

/**
 * @generated
 */
public class MazePaletteFactory {

	/**
	* @generated
	*/
	public void fillPalette(PaletteRoot paletteRoot) {
		paletteRoot.add(createObjects1Group());
		paletteRoot.add(createConnections2Group());
	}

	/**
	* Creates "Objects" palette tool group
	* @generated
	*/
	private PaletteContainer createObjects1Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(Maze.diagram.part.Messages.Objects1Group_title);
		paletteContainer.setId("createObjects1Group"); //$NON-NLS-1$
		paletteContainer.add(createCellPoint1CreationTool());
		paletteContainer.add(createColumnCount2CreationTool());
		paletteContainer.add(createDecisionsRate3CreationTool());
		paletteContainer.add(createEndPoint4CreationTool());
		paletteContainer.add(createEndRate5CreationTool());
		paletteContainer.add(createForcePatternGenerator6CreationTool());
		paletteContainer.add(createMazeBodyGenerator7CreationTool());
		paletteContainer.add(createMazeCell8CreationTool());
		paletteContainer.add(createRectangleGenerator9CreationTool());
		paletteContainer.add(createRowCount10CreationTool());
		paletteContainer.add(createSolutionPathGenerator11CreationTool());
		paletteContainer.add(createStartPoint12CreationTool());
		paletteContainer.add(createStraightRate13CreationTool());
		paletteContainer.add(createTurnRate14CreationTool());
		return paletteContainer;
	}

	/**
	* Creates "Connections" palette tool group
	* @generated
	*/
	private PaletteContainer createConnections2Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(Maze.diagram.part.Messages.Connections2Group_title);
		paletteContainer.setId("createConnections2Group"); //$NON-NLS-1$
		paletteContainer.add(createFpg1CreationTool());
		paletteContainer.add(createMbg2CreationTool());
		paletteContainer.add(createSpg3CreationTool());
		return paletteContainer;
	}

	/**
	* @generated
	*/
	private ToolEntry createCellPoint1CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(Maze.diagram.part.Messages.CellPoint1CreationTool_title,
				Maze.diagram.part.Messages.CellPoint1CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.CellPoint_3004));
		entry.setId("createCellPoint1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.CellPoint_3004));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createColumnCount2CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(Maze.diagram.part.Messages.ColumnCount2CreationTool_title,
				Maze.diagram.part.Messages.ColumnCount2CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.ColumnCount_3002));
		entry.setId("createColumnCount2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.ColumnCount_3002));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createDecisionsRate3CreationTool() {
		ArrayList<IElementType> types = new ArrayList<IElementType>(2);
		types.add(Maze.diagram.providers.MazeElementTypes.DecisionsRate_3007);
		types.add(Maze.diagram.providers.MazeElementTypes.DecisionsRate_3010);
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				Maze.diagram.part.Messages.DecisionsRate3CreationTool_title,
				Maze.diagram.part.Messages.DecisionsRate3CreationTool_desc, types);
		entry.setId("createDecisionsRate3CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.DecisionsRate_3007));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createEndPoint4CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(Maze.diagram.part.Messages.EndPoint4CreationTool_title,
				Maze.diagram.part.Messages.EndPoint4CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.EndPoint_3009));
		entry.setId("createEndPoint4CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.EndPoint_3009));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createEndRate5CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(Maze.diagram.part.Messages.EndRate5CreationTool_title,
				Maze.diagram.part.Messages.EndRate5CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.EndRate_3013));
		entry.setId("createEndRate5CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.EndRate_3013));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createForcePatternGenerator6CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				Maze.diagram.part.Messages.ForcePatternGenerator6CreationTool_title,
				Maze.diagram.part.Messages.ForcePatternGenerator6CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.ForcePatternGenerator_2002));
		entry.setId("createForcePatternGenerator6CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.ForcePatternGenerator_2002));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createMazeBodyGenerator7CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				Maze.diagram.part.Messages.MazeBodyGenerator7CreationTool_title,
				Maze.diagram.part.Messages.MazeBodyGenerator7CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.MazeBodyGenerator_2004));
		entry.setId("createMazeBodyGenerator7CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.MazeBodyGenerator_2004));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createMazeCell8CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(Maze.diagram.part.Messages.MazeCell8CreationTool_title,
				Maze.diagram.part.Messages.MazeCell8CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.MazeCell_3003));
		entry.setId("createMazeCell8CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.MazeCell_3003));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createRectangleGenerator9CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				Maze.diagram.part.Messages.RectangleGenerator9CreationTool_title,
				Maze.diagram.part.Messages.RectangleGenerator9CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.RectangleGenerator_2001));
		entry.setId("createRectangleGenerator9CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.RectangleGenerator_2001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createRowCount10CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(Maze.diagram.part.Messages.RowCount10CreationTool_title,
				Maze.diagram.part.Messages.RowCount10CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.RowCount_3001));
		entry.setId("createRowCount10CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.RowCount_3001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createSolutionPathGenerator11CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				Maze.diagram.part.Messages.SolutionPathGenerator11CreationTool_title,
				Maze.diagram.part.Messages.SolutionPathGenerator11CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.SolutionPathGenerator_2003));
		entry.setId("createSolutionPathGenerator11CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.SolutionPathGenerator_2003));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createStartPoint12CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(Maze.diagram.part.Messages.StartPoint12CreationTool_title,
				Maze.diagram.part.Messages.StartPoint12CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.StartPoint_3008));
		entry.setId("createStartPoint12CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.StartPoint_3008));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createStraightRate13CreationTool() {
		ArrayList<IElementType> types = new ArrayList<IElementType>(2);
		types.add(Maze.diagram.providers.MazeElementTypes.StraightRate_3006);
		types.add(Maze.diagram.providers.MazeElementTypes.StraightRate_3011);
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				Maze.diagram.part.Messages.StraightRate13CreationTool_title,
				Maze.diagram.part.Messages.StraightRate13CreationTool_desc, types);
		entry.setId("createStraightRate13CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.StraightRate_3006));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createTurnRate14CreationTool() {
		ArrayList<IElementType> types = new ArrayList<IElementType>(2);
		types.add(Maze.diagram.providers.MazeElementTypes.TurnRate_3005);
		types.add(Maze.diagram.providers.MazeElementTypes.TurnRate_3012);
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(Maze.diagram.part.Messages.TurnRate14CreationTool_title,
				Maze.diagram.part.Messages.TurnRate14CreationTool_desc, types);
		entry.setId("createTurnRate14CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.TurnRate_3005));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createFpg1CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(Maze.diagram.part.Messages.Fpg1CreationTool_title,
				Maze.diagram.part.Messages.Fpg1CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.RectangleGeneratorFpg_4001));
		entry.setId("createFpg1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.RectangleGeneratorFpg_4001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createMbg2CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(Maze.diagram.part.Messages.Mbg2CreationTool_title,
				Maze.diagram.part.Messages.Mbg2CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.SolutionPathGeneratorMbg_4003));
		entry.setId("createMbg2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.SolutionPathGeneratorMbg_4003));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createSpg3CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(Maze.diagram.part.Messages.Spg3CreationTool_title,
				Maze.diagram.part.Messages.Spg3CreationTool_desc,
				Collections.singletonList(Maze.diagram.providers.MazeElementTypes.ForcePatternGeneratorSpg_4002));
		entry.setId("createSpg3CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(Maze.diagram.providers.MazeElementTypes
				.getImageDescriptor(Maze.diagram.providers.MazeElementTypes.ForcePatternGeneratorSpg_4002));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

}
