/*
 * 
 */
package Maze.diagram.part;

import org.eclipse.osgi.util.NLS;

/**
 * @generated
 */
public class Messages extends NLS {

	/**
	* @generated
	*/
	static {
		NLS.initializeMessages("messages", Messages.class); //$NON-NLS-1$
	}

	/**
	* @generated
	*/
	private Messages() {
	}

	/**
	* @generated
	*/
	public static String MazeCreationWizardTitle;

	/**
	* @generated
	*/
	public static String MazeCreationWizard_DiagramModelFilePageTitle;

	/**
	* @generated
	*/
	public static String MazeCreationWizard_DiagramModelFilePageDescription;

	/**
	* @generated
	*/
	public static String MazeCreationWizard_DomainModelFilePageTitle;

	/**
	* @generated
	*/
	public static String MazeCreationWizard_DomainModelFilePageDescription;

	/**
	* @generated
	*/
	public static String MazeCreationWizardOpenEditorError;

	/**
	* @generated
	*/
	public static String MazeCreationWizardCreationError;

	/**
	* @generated
	*/
	public static String MazeCreationWizardPageExtensionError;

	/**
	* @generated
	*/
	public static String MazeDiagramEditorUtil_OpenModelResourceErrorDialogTitle;

	/**
	* @generated
	*/
	public static String MazeDiagramEditorUtil_OpenModelResourceErrorDialogMessage;

	/**
	* @generated
	*/
	public static String MazeDiagramEditorUtil_CreateDiagramProgressTask;

	/**
	* @generated
	*/
	public static String MazeDiagramEditorUtil_CreateDiagramCommandLabel;

	/**
	* @generated
	*/
	public static String MazeDocumentProvider_isModifiable;

	/**
	* @generated
	*/
	public static String MazeDocumentProvider_handleElementContentChanged;

	/**
	* @generated
	*/
	public static String MazeDocumentProvider_IncorrectInputError;

	/**
	* @generated
	*/
	public static String MazeDocumentProvider_NoDiagramInResourceError;

	/**
	* @generated
	*/
	public static String MazeDocumentProvider_DiagramLoadingError;

	/**
	* @generated
	*/
	public static String MazeDocumentProvider_UnsynchronizedFileSaveError;

	/**
	* @generated
	*/
	public static String MazeDocumentProvider_SaveDiagramTask;

	/**
	* @generated
	*/
	public static String MazeDocumentProvider_SaveNextResourceTask;

	/**
	* @generated
	*/
	public static String MazeDocumentProvider_SaveAsOperation;

	/**
	* @generated
	*/
	public static String InitDiagramFile_ResourceErrorDialogTitle;

	/**
	* @generated
	*/
	public static String InitDiagramFile_ResourceErrorDialogMessage;

	/**
	* @generated
	*/
	public static String InitDiagramFile_WizardTitle;

	/**
	* @generated
	*/
	public static String InitDiagramFile_OpenModelFileDialogTitle;

	/**
	* @generated
	*/
	public static String MazeNewDiagramFileWizard_CreationPageName;

	/**
	* @generated
	*/
	public static String MazeNewDiagramFileWizard_CreationPageTitle;

	/**
	* @generated
	*/
	public static String MazeNewDiagramFileWizard_CreationPageDescription;

	/**
	* @generated
	*/
	public static String MazeNewDiagramFileWizard_RootSelectionPageName;

	/**
	* @generated
	*/
	public static String MazeNewDiagramFileWizard_RootSelectionPageTitle;

	/**
	* @generated
	*/
	public static String MazeNewDiagramFileWizard_RootSelectionPageDescription;

	/**
	* @generated
	*/
	public static String MazeNewDiagramFileWizard_RootSelectionPageSelectionTitle;

	/**
	* @generated
	*/
	public static String MazeNewDiagramFileWizard_RootSelectionPageNoSelectionMessage;

	/**
	* @generated
	*/
	public static String MazeNewDiagramFileWizard_RootSelectionPageInvalidSelectionMessage;

	/**
	* @generated
	*/
	public static String MazeNewDiagramFileWizard_InitDiagramCommand;

	/**
	* @generated
	*/
	public static String MazeNewDiagramFileWizard_IncorrectRootError;

	/**
	* @generated
	*/
	public static String MazeDiagramEditor_SavingDeletedFile;

	/**
	* @generated
	*/
	public static String MazeDiagramEditor_SaveAsErrorTitle;

	/**
	* @generated
	*/
	public static String MazeDiagramEditor_SaveAsErrorMessage;

	/**
	* @generated
	*/
	public static String MazeDiagramEditor_SaveErrorTitle;

	/**
	* @generated
	*/
	public static String MazeDiagramEditor_SaveErrorMessage;

	/**
	* @generated
	*/
	public static String MazeElementChooserDialog_SelectModelElementTitle;

	/**
	* @generated
	*/
	public static String ModelElementSelectionPageMessage;

	/**
	* @generated
	*/
	public static String ValidateActionMessage;

	/**
	* @generated
	*/
	public static String Objects1Group_title;

	/**
	* @generated
	*/
	public static String Connections2Group_title;

	/**
	* @generated
	*/
	public static String ColumnCount1CreationTool_title;

	/**
	* @generated
	*/
	public static String ColumnCount1CreationTool_desc;

	/**
	* @generated
	*/
	public static String DecisionsRate2CreationTool_title;

	/**
	* @generated
	*/
	public static String DecisionsRate2CreationTool_desc;

	/**
	* @generated
	*/
	public static String RandomMazeBodyGenerator3CreationTool_title;

	/**
	* @generated
	*/
	public static String RandomMazeBodyGenerator3CreationTool_desc;

	/**
	* @generated
	*/
	public static String RectangleGenerator4CreationTool_title;

	/**
	* @generated
	*/
	public static String RectangleGenerator4CreationTool_desc;

	/**
	* @generated
	*/
	public static String RowCount5CreationTool_title;

	/**
	* @generated
	*/
	public static String RowCount5CreationTool_desc;

	/**
	* @generated
	*/
	public static String SolutionPathGenerator6CreationTool_title;

	/**
	* @generated
	*/
	public static String SolutionPathGenerator6CreationTool_desc;

	/**
	* @generated
	*/
	public static String StackMazeBodyGenerator7CreationTool_title;

	/**
	* @generated
	*/
	public static String StackMazeBodyGenerator7CreationTool_desc;

	/**
	* @generated
	*/
	public static String StraightRate8CreationTool_title;

	/**
	* @generated
	*/
	public static String StraightRate8CreationTool_desc;

	/**
	* @generated
	*/
	public static String TurnRate9CreationTool_title;

	/**
	* @generated
	*/
	public static String TurnRate9CreationTool_desc;

	/**
	* @generated
	*/
	public static String Mbg1CreationTool_title;

	/**
	* @generated
	*/
	public static String Mbg1CreationTool_desc;

	/**
	* @generated
	*/
	public static String Spg2CreationTool_title;

	/**
	* @generated
	*/
	public static String Spg2CreationTool_desc;

	/**
	* @generated
	*/
	public static String StackMazeBodyGeneratorStackMazeBodyGeneratorDrCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String StackMazeBodyGeneratorStackMazeBodyGeneratorSrCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String StackMazeBodyGeneratorStackMazeBodyGeneratorTrCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String RandomMazeBodyGeneratorRandomMazeBodyGeneratorDrCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String RandomMazeBodyGeneratorRandomMazeBodyGeneratorSrCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String RandomMazeBodyGeneratorRandomMazeBodyGeneratorTrCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String RectangleGeneratorRectangleGeneratorRcCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String RectangleGeneratorRectangleGeneratorCcCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String SolutionPathGeneratorSolutionPathGeneratorTrCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String SolutionPathGeneratorSolutionPathGeneratorSrCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String SolutionPathGeneratorSolutionPathGeneratorDrCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String CommandName_OpenDiagram;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_MazeDiagram_1000_links;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_RectangleGenerator_2003_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_SolutionPathGenerator_2004_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_SolutionPathGenerator_2004_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_StackMazeBodyGenerator_2005_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_RandomMazeBodyGenerator_2006_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_RectangleGeneratorSpg_4001_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_RectangleGeneratorSpg_4001_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_SolutionPathGeneratorMbg_4002_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_SolutionPathGeneratorMbg_4002_source;

	/**
	* @generated
	*/
	public static String NavigatorActionProvider_OpenDiagramActionName;

	/**
	* @generated
	*/
	public static String MessageFormatParser_InvalidInputError;

	/**
	* @generated
	*/
	public static String MazeModelingAssistantProviderTitle;

	/**
	* @generated
	*/
	public static String MazeModelingAssistantProviderMessage;

	//TODO: put accessor fields manually	
}
