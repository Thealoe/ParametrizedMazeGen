/*
* 
*/
package Maze.diagram.part;

import org.eclipse.core.runtime.Platform;
import org.eclipse.emf.ecore.EAnnotation;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.notation.Diagram;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.gmf.tooling.runtime.structure.DiagramStructure;

/**
 * This registry is used to determine which type of visual object should be
 * created for the corresponding Diagram, Node, ChildNode or Link represented
 * by a domain model object.
 * 
 * @generated
 */
public class MazeVisualIDRegistry {

	/**
	* @generated
	*/
	private static final String DEBUG_KEY = "Maze.diagram/debug/visualID"; //$NON-NLS-1$

	/**
	* @generated
	*/
	public static int getVisualID(View view) {
		if (view instanceof Diagram) {
			if (Maze.diagram.edit.parts.MazeDiagramEditPart.MODEL_ID.equals(view.getType())) {
				return Maze.diagram.edit.parts.MazeDiagramEditPart.VISUAL_ID;
			} else {
				return -1;
			}
		}
		return Maze.diagram.part.MazeVisualIDRegistry.getVisualID(view.getType());
	}

	/**
	* @generated
	*/
	public static String getModelID(View view) {
		View diagram = view.getDiagram();
		while (view != diagram) {
			EAnnotation annotation = view.getEAnnotation("Shortcut"); //$NON-NLS-1$
			if (annotation != null) {
				return (String) annotation.getDetails().get("modelID"); //$NON-NLS-1$
			}
			view = (View) view.eContainer();
		}
		return diagram != null ? diagram.getType() : null;
	}

	/**
	* @generated
	*/
	public static int getVisualID(String type) {
		try {
			return Integer.parseInt(type);
		} catch (NumberFormatException e) {
			if (Boolean.TRUE.toString().equalsIgnoreCase(Platform.getDebugOption(DEBUG_KEY))) {
				Maze.diagram.part.MazeDiagramEditorPlugin.getInstance()
						.logError("Unable to parse view type as a visualID number: " + type);
			}
		}
		return -1;
	}

	/**
	* @generated
	*/
	public static String getType(int visualID) {
		return Integer.toString(visualID);
	}

	/**
	* @generated
	*/
	public static int getDiagramVisualID(EObject domainElement) {
		if (domainElement == null) {
			return -1;
		}
		if (Maze.MazePackage.eINSTANCE.getMazeDiagram().isSuperTypeOf(domainElement.eClass())
				&& isDiagram((Maze.MazeDiagram) domainElement)) {
			return Maze.diagram.edit.parts.MazeDiagramEditPart.VISUAL_ID;
		}
		return -1;
	}

	/**
	* @generated
	*/
	public static int getNodeVisualID(View containerView, EObject domainElement) {
		if (domainElement == null) {
			return -1;
		}
		String containerModelID = Maze.diagram.part.MazeVisualIDRegistry.getModelID(containerView);
		if (!Maze.diagram.edit.parts.MazeDiagramEditPart.MODEL_ID.equals(containerModelID)
				&& !"mz".equals(containerModelID)) { //$NON-NLS-1$
			return -1;
		}
		int containerVisualID;
		if (Maze.diagram.edit.parts.MazeDiagramEditPart.MODEL_ID.equals(containerModelID)) {
			containerVisualID = Maze.diagram.part.MazeVisualIDRegistry.getVisualID(containerView);
		} else {
			if (containerView instanceof Diagram) {
				containerVisualID = Maze.diagram.edit.parts.MazeDiagramEditPart.VISUAL_ID;
			} else {
				return -1;
			}
		}
		switch (containerVisualID) {
		case Maze.diagram.edit.parts.MazeDiagramEditPart.VISUAL_ID:
			if (Maze.MazePackage.eINSTANCE.getRectangleGenerator().isSuperTypeOf(domainElement.eClass())) {
				return Maze.diagram.edit.parts.RectangleGeneratorEditPart.VISUAL_ID;
			}
			if (Maze.MazePackage.eINSTANCE.getForcePatternGenerator().isSuperTypeOf(domainElement.eClass())) {
				return Maze.diagram.edit.parts.ForcePatternGeneratorEditPart.VISUAL_ID;
			}
			if (Maze.MazePackage.eINSTANCE.getSolutionPathGenerator().isSuperTypeOf(domainElement.eClass())) {
				return Maze.diagram.edit.parts.SolutionPathGeneratorEditPart.VISUAL_ID;
			}
			if (Maze.MazePackage.eINSTANCE.getMazeBodyGenerator().isSuperTypeOf(domainElement.eClass())) {
				return Maze.diagram.edit.parts.MazeBodyGeneratorEditPart.VISUAL_ID;
			}
			break;
		case Maze.diagram.edit.parts.RectangleGeneratorRectangleGeneratorRcCompartmentEditPart.VISUAL_ID:
			if (Maze.MazePackage.eINSTANCE.getRowCount().isSuperTypeOf(domainElement.eClass())) {
				return Maze.diagram.edit.parts.RowCountEditPart.VISUAL_ID;
			}
			break;
		case Maze.diagram.edit.parts.RectangleGeneratorRectangleGeneratorCcCompartmentEditPart.VISUAL_ID:
			if (Maze.MazePackage.eINSTANCE.getColumnCount().isSuperTypeOf(domainElement.eClass())) {
				return Maze.diagram.edit.parts.ColumnCountEditPart.VISUAL_ID;
			}
			break;
		case Maze.diagram.edit.parts.ForcePatternGeneratorForcePatternGeneratorMazeCellsCompartmentEditPart.VISUAL_ID:
			if (Maze.MazePackage.eINSTANCE.getMazeCell().isSuperTypeOf(domainElement.eClass())) {
				return Maze.diagram.edit.parts.MazeCellEditPart.VISUAL_ID;
			}
			break;
		case Maze.diagram.edit.parts.MazeCellMazeCellPointCompartmentEditPart.VISUAL_ID:
			if (Maze.MazePackage.eINSTANCE.getCellPoint().isSuperTypeOf(domainElement.eClass())) {
				return Maze.diagram.edit.parts.CellPointEditPart.VISUAL_ID;
			}
			break;
		case Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorTrCompartmentEditPart.VISUAL_ID:
			if (Maze.MazePackage.eINSTANCE.getTurnRate().isSuperTypeOf(domainElement.eClass())) {
				return Maze.diagram.edit.parts.TurnRateEditPart.VISUAL_ID;
			}
			break;
		case Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorSrCompartmentEditPart.VISUAL_ID:
			if (Maze.MazePackage.eINSTANCE.getStraightRate().isSuperTypeOf(domainElement.eClass())) {
				return Maze.diagram.edit.parts.StraightRateEditPart.VISUAL_ID;
			}
			break;
		case Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorDrCompartmentEditPart.VISUAL_ID:
			if (Maze.MazePackage.eINSTANCE.getDecisionsRate().isSuperTypeOf(domainElement.eClass())) {
				return Maze.diagram.edit.parts.DecisionsRateEditPart.VISUAL_ID;
			}
			break;
		case Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorSpCompartmentEditPart.VISUAL_ID:
			if (Maze.MazePackage.eINSTANCE.getStartPoint().isSuperTypeOf(domainElement.eClass())) {
				return Maze.diagram.edit.parts.StartPointEditPart.VISUAL_ID;
			}
			break;
		case Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorEpCompartmentEditPart.VISUAL_ID:
			if (Maze.MazePackage.eINSTANCE.getEndPoint().isSuperTypeOf(domainElement.eClass())) {
				return Maze.diagram.edit.parts.EndPointEditPart.VISUAL_ID;
			}
			break;
		case Maze.diagram.edit.parts.MazeBodyGeneratorMazeBodyGeneratorDrCompartmentEditPart.VISUAL_ID:
			if (Maze.MazePackage.eINSTANCE.getDecisionsRate().isSuperTypeOf(domainElement.eClass())) {
				return Maze.diagram.edit.parts.DecisionsRate2EditPart.VISUAL_ID;
			}
			break;
		case Maze.diagram.edit.parts.MazeBodyGeneratorMazeBodyGeneratorSrCompartmentEditPart.VISUAL_ID:
			if (Maze.MazePackage.eINSTANCE.getStraightRate().isSuperTypeOf(domainElement.eClass())) {
				return Maze.diagram.edit.parts.StraightRate2EditPart.VISUAL_ID;
			}
			break;
		case Maze.diagram.edit.parts.MazeBodyGeneratorMazeBodyGeneratorTrCompartmentEditPart.VISUAL_ID:
			if (Maze.MazePackage.eINSTANCE.getTurnRate().isSuperTypeOf(domainElement.eClass())) {
				return Maze.diagram.edit.parts.TurnRate2EditPart.VISUAL_ID;
			}
			break;
		case Maze.diagram.edit.parts.MazeBodyGeneratorMazeBodyGeneratorErCompartmentEditPart.VISUAL_ID:
			if (Maze.MazePackage.eINSTANCE.getEndRate().isSuperTypeOf(domainElement.eClass())) {
				return Maze.diagram.edit.parts.EndRateEditPart.VISUAL_ID;
			}
			break;
		}
		return -1;
	}

	/**
	* @generated
	*/
	public static boolean canCreateNode(View containerView, int nodeVisualID) {
		String containerModelID = Maze.diagram.part.MazeVisualIDRegistry.getModelID(containerView);
		if (!Maze.diagram.edit.parts.MazeDiagramEditPart.MODEL_ID.equals(containerModelID)
				&& !"mz".equals(containerModelID)) { //$NON-NLS-1$
			return false;
		}
		int containerVisualID;
		if (Maze.diagram.edit.parts.MazeDiagramEditPart.MODEL_ID.equals(containerModelID)) {
			containerVisualID = Maze.diagram.part.MazeVisualIDRegistry.getVisualID(containerView);
		} else {
			if (containerView instanceof Diagram) {
				containerVisualID = Maze.diagram.edit.parts.MazeDiagramEditPart.VISUAL_ID;
			} else {
				return false;
			}
		}
		switch (containerVisualID) {
		case Maze.diagram.edit.parts.MazeDiagramEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.RectangleGeneratorEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (Maze.diagram.edit.parts.ForcePatternGeneratorEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (Maze.diagram.edit.parts.SolutionPathGeneratorEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (Maze.diagram.edit.parts.MazeBodyGeneratorEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.RectangleGeneratorEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.RectangleGeneratorNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (Maze.diagram.edit.parts.RectangleGeneratorRectangleGeneratorRcCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (Maze.diagram.edit.parts.RectangleGeneratorRectangleGeneratorCcCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.ForcePatternGeneratorEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.ForcePatternGeneratorNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (Maze.diagram.edit.parts.ForcePatternGeneratorForcePatternGeneratorMazeCellsCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.SolutionPathGeneratorEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.SolutionPathGeneratorNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorTrCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorSrCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorDrCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorSpCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorEpCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.MazeBodyGeneratorEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.MazeBodyGeneratorNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (Maze.diagram.edit.parts.MazeBodyGeneratorMazeBodyGeneratorDrCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (Maze.diagram.edit.parts.MazeBodyGeneratorMazeBodyGeneratorSrCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (Maze.diagram.edit.parts.MazeBodyGeneratorMazeBodyGeneratorTrCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (Maze.diagram.edit.parts.MazeBodyGeneratorMazeBodyGeneratorErCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.RowCountEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.RowCountNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.ColumnCountEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.ColumnCountNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.MazeCellEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.MazeCellTypeEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (Maze.diagram.edit.parts.MazeCellMazeCellPointCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.CellPointEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.CellPointNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.TurnRateEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.TurnRateNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.StraightRateEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.StraightRateNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.DecisionsRateEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.DecisionsRateNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.StartPointEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.StartPointNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.EndPointEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.EndPointNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.DecisionsRate2EditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.DecisionsRateName2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.StraightRate2EditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.StraightRateName2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.TurnRate2EditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.TurnRateName2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.EndRateEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.EndRateNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.RectangleGeneratorRectangleGeneratorRcCompartmentEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.RowCountEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.RectangleGeneratorRectangleGeneratorCcCompartmentEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.ColumnCountEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.ForcePatternGeneratorForcePatternGeneratorMazeCellsCompartmentEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.MazeCellEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.MazeCellMazeCellPointCompartmentEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.CellPointEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorTrCompartmentEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.TurnRateEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorSrCompartmentEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.StraightRateEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorDrCompartmentEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.DecisionsRateEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorSpCompartmentEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.StartPointEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorEpCompartmentEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.EndPointEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.MazeBodyGeneratorMazeBodyGeneratorDrCompartmentEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.DecisionsRate2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.MazeBodyGeneratorMazeBodyGeneratorSrCompartmentEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.StraightRate2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.MazeBodyGeneratorMazeBodyGeneratorTrCompartmentEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.TurnRate2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.MazeBodyGeneratorMazeBodyGeneratorErCompartmentEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.EndRateEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.RectangleGeneratorFpgEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.WrappingLabelEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.ForcePatternGeneratorSpgEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.WrappingLabel2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Maze.diagram.edit.parts.SolutionPathGeneratorMbgEditPart.VISUAL_ID:
			if (Maze.diagram.edit.parts.WrappingLabel3EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		}
		return false;
	}

	/**
	* @generated
	*/
	public static int getLinkWithClassVisualID(EObject domainElement) {
		if (domainElement == null) {
			return -1;
		}
		return -1;
	}

	/**
	* User can change implementation of this method to handle some specific
	* situations not covered by default logic.
	* 
	* @generated
	*/
	private static boolean isDiagram(Maze.MazeDiagram element) {
		return true;
	}

	/**
	* @generated
	*/
	public static boolean checkNodeVisualID(View containerView, EObject domainElement, int candidate) {
		if (candidate == -1) {
			//unrecognized id is always bad
			return false;
		}
		int basic = getNodeVisualID(containerView, domainElement);
		return basic == candidate;
	}

	/**
	* @generated
	*/
	public static boolean isCompartmentVisualID(int visualID) {
		switch (visualID) {
		case Maze.diagram.edit.parts.RectangleGeneratorRectangleGeneratorRcCompartmentEditPart.VISUAL_ID:
		case Maze.diagram.edit.parts.RectangleGeneratorRectangleGeneratorCcCompartmentEditPart.VISUAL_ID:
		case Maze.diagram.edit.parts.ForcePatternGeneratorForcePatternGeneratorMazeCellsCompartmentEditPart.VISUAL_ID:
		case Maze.diagram.edit.parts.MazeCellMazeCellPointCompartmentEditPart.VISUAL_ID:
		case Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorTrCompartmentEditPart.VISUAL_ID:
		case Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorSrCompartmentEditPart.VISUAL_ID:
		case Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorDrCompartmentEditPart.VISUAL_ID:
		case Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorSpCompartmentEditPart.VISUAL_ID:
		case Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorEpCompartmentEditPart.VISUAL_ID:
		case Maze.diagram.edit.parts.MazeBodyGeneratorMazeBodyGeneratorDrCompartmentEditPart.VISUAL_ID:
		case Maze.diagram.edit.parts.MazeBodyGeneratorMazeBodyGeneratorSrCompartmentEditPart.VISUAL_ID:
		case Maze.diagram.edit.parts.MazeBodyGeneratorMazeBodyGeneratorTrCompartmentEditPart.VISUAL_ID:
		case Maze.diagram.edit.parts.MazeBodyGeneratorMazeBodyGeneratorErCompartmentEditPart.VISUAL_ID:
			return true;
		default:
			break;
		}
		return false;
	}

	/**
	* @generated
	*/
	public static boolean isSemanticLeafVisualID(int visualID) {
		switch (visualID) {
		case Maze.diagram.edit.parts.MazeDiagramEditPart.VISUAL_ID:
			return false;
		case Maze.diagram.edit.parts.RowCountEditPart.VISUAL_ID:
		case Maze.diagram.edit.parts.ColumnCountEditPart.VISUAL_ID:
		case Maze.diagram.edit.parts.CellPointEditPart.VISUAL_ID:
		case Maze.diagram.edit.parts.TurnRateEditPart.VISUAL_ID:
		case Maze.diagram.edit.parts.StraightRateEditPart.VISUAL_ID:
		case Maze.diagram.edit.parts.DecisionsRateEditPart.VISUAL_ID:
		case Maze.diagram.edit.parts.StartPointEditPart.VISUAL_ID:
		case Maze.diagram.edit.parts.EndPointEditPart.VISUAL_ID:
		case Maze.diagram.edit.parts.DecisionsRate2EditPart.VISUAL_ID:
		case Maze.diagram.edit.parts.StraightRate2EditPart.VISUAL_ID:
		case Maze.diagram.edit.parts.TurnRate2EditPart.VISUAL_ID:
		case Maze.diagram.edit.parts.EndRateEditPart.VISUAL_ID:
			return true;
		default:
			break;
		}
		return false;
	}

	/**
	* @generated
	*/
	public static final DiagramStructure TYPED_INSTANCE = new DiagramStructure() {
		/**
		* @generated
		*/
		@Override

		public int getVisualID(View view) {
			return Maze.diagram.part.MazeVisualIDRegistry.getVisualID(view);
		}

		/**
		* @generated
		*/
		@Override

		public String getModelID(View view) {
			return Maze.diagram.part.MazeVisualIDRegistry.getModelID(view);
		}

		/**
		* @generated
		*/
		@Override

		public int getNodeVisualID(View containerView, EObject domainElement) {
			return Maze.diagram.part.MazeVisualIDRegistry.getNodeVisualID(containerView, domainElement);
		}

		/**
		* @generated
		*/
		@Override

		public boolean checkNodeVisualID(View containerView, EObject domainElement, int candidate) {
			return Maze.diagram.part.MazeVisualIDRegistry.checkNodeVisualID(containerView, domainElement, candidate);
		}

		/**
		* @generated
		*/
		@Override

		public boolean isCompartmentVisualID(int visualID) {
			return Maze.diagram.part.MazeVisualIDRegistry.isCompartmentVisualID(visualID);
		}

		/**
		* @generated
		*/
		@Override

		public boolean isSemanticLeafVisualID(int visualID) {
			return Maze.diagram.part.MazeVisualIDRegistry.isSemanticLeafVisualID(visualID);
		}
	};

}
