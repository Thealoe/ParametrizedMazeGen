/*
* 
*/
package Maze.diagram.part;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.tooling.runtime.update.UpdaterNodeDescriptor;

/**
 * @generated
 */
public class MazeNodeDescriptor extends UpdaterNodeDescriptor {
	/**
	* @generated
	*/
	public MazeNodeDescriptor(EObject modelElement, int visualID) {
		super(modelElement, visualID);
	}

}
