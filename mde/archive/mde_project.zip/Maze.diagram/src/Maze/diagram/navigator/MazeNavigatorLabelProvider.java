/*
* 
*/
package Maze.diagram.navigator;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.gmf.runtime.common.ui.services.parser.CommonParserHint;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParser;
import org.eclipse.gmf.runtime.common.ui.services.parser.ParserOptions;
import org.eclipse.gmf.runtime.emf.core.util.EObjectAdapter;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.jface.viewers.ITreePathLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TreePath;
import org.eclipse.jface.viewers.ViewerLabel;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.IMemento;
import org.eclipse.ui.navigator.ICommonContentExtensionSite;
import org.eclipse.ui.navigator.ICommonLabelProvider;

/**
 * @generated
 */
public class MazeNavigatorLabelProvider extends LabelProvider implements ICommonLabelProvider, ITreePathLabelProvider {

	/**
	* @generated
	*/
	static {
		Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().getImageRegistry().put("Navigator?UnknownElement", //$NON-NLS-1$
				ImageDescriptor.getMissingImageDescriptor());
		Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().getImageRegistry().put("Navigator?ImageNotFound", //$NON-NLS-1$
				ImageDescriptor.getMissingImageDescriptor());
	}

	/**
	* @generated
	*/
	public void updateLabel(ViewerLabel label, TreePath elementPath) {
		Object element = elementPath.getLastSegment();
		if (element instanceof Maze.diagram.navigator.MazeNavigatorItem
				&& !isOwnView(((Maze.diagram.navigator.MazeNavigatorItem) element).getView())) {
			return;
		}
		label.setText(getText(element));
		label.setImage(getImage(element));
	}

	/**
	* @generated
	*/
	public Image getImage(Object element) {
		if (element instanceof Maze.diagram.navigator.MazeNavigatorGroup) {
			Maze.diagram.navigator.MazeNavigatorGroup group = (Maze.diagram.navigator.MazeNavigatorGroup) element;
			return Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().getBundledImage(group.getIcon());
		}

		if (element instanceof Maze.diagram.navigator.MazeNavigatorItem) {
			Maze.diagram.navigator.MazeNavigatorItem navigatorItem = (Maze.diagram.navigator.MazeNavigatorItem) element;
			if (!isOwnView(navigatorItem.getView())) {
				return super.getImage(element);
			}
			return getImage(navigatorItem.getView());
		}

		// Due to plugin.xml content will be called only for "own" views
		if (element instanceof IAdaptable) {
			View view = (View) ((IAdaptable) element).getAdapter(View.class);
			if (view != null && isOwnView(view)) {
				return getImage(view);
			}
		}

		return super.getImage(element);
	}

	/**
	* @generated
	*/
	public Image getImage(View view) {
		switch (Maze.diagram.part.MazeVisualIDRegistry.getVisualID(view)) {
		case Maze.diagram.edit.parts.MazeDiagramEditPart.VISUAL_ID:
			return getImage("Navigator?Diagram?geodes.sms.maze?MazeDiagram", //$NON-NLS-1$
					Maze.diagram.providers.MazeElementTypes.MazeDiagram_1000);
		case Maze.diagram.edit.parts.RectangleGeneratorEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?geodes.sms.maze?RectangleGenerator", //$NON-NLS-1$
					Maze.diagram.providers.MazeElementTypes.RectangleGenerator_2001);
		case Maze.diagram.edit.parts.ForcePatternGeneratorEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?geodes.sms.maze?ForcePatternGenerator", //$NON-NLS-1$
					Maze.diagram.providers.MazeElementTypes.ForcePatternGenerator_2002);
		case Maze.diagram.edit.parts.SolutionPathGeneratorEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?geodes.sms.maze?SolutionPathGenerator", //$NON-NLS-1$
					Maze.diagram.providers.MazeElementTypes.SolutionPathGenerator_2003);
		case Maze.diagram.edit.parts.MazeBodyGeneratorEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?geodes.sms.maze?MazeBodyGenerator", //$NON-NLS-1$
					Maze.diagram.providers.MazeElementTypes.MazeBodyGenerator_2004);
		case Maze.diagram.edit.parts.RowCountEditPart.VISUAL_ID:
			return getImage("Navigator?Node?geodes.sms.maze?RowCount", //$NON-NLS-1$
					Maze.diagram.providers.MazeElementTypes.RowCount_3001);
		case Maze.diagram.edit.parts.ColumnCountEditPart.VISUAL_ID:
			return getImage("Navigator?Node?geodes.sms.maze?ColumnCount", //$NON-NLS-1$
					Maze.diagram.providers.MazeElementTypes.ColumnCount_3002);
		case Maze.diagram.edit.parts.MazeCellEditPart.VISUAL_ID:
			return getImage("Navigator?Node?geodes.sms.maze?MazeCell", //$NON-NLS-1$
					Maze.diagram.providers.MazeElementTypes.MazeCell_3003);
		case Maze.diagram.edit.parts.CellPointEditPart.VISUAL_ID:
			return getImage("Navigator?Node?geodes.sms.maze?CellPoint", //$NON-NLS-1$
					Maze.diagram.providers.MazeElementTypes.CellPoint_3004);
		case Maze.diagram.edit.parts.TurnRateEditPart.VISUAL_ID:
			return getImage("Navigator?Node?geodes.sms.maze?TurnRate", //$NON-NLS-1$
					Maze.diagram.providers.MazeElementTypes.TurnRate_3005);
		case Maze.diagram.edit.parts.StraightRateEditPart.VISUAL_ID:
			return getImage("Navigator?Node?geodes.sms.maze?StraightRate", //$NON-NLS-1$
					Maze.diagram.providers.MazeElementTypes.StraightRate_3006);
		case Maze.diagram.edit.parts.DecisionsRateEditPart.VISUAL_ID:
			return getImage("Navigator?Node?geodes.sms.maze?DecisionsRate", //$NON-NLS-1$
					Maze.diagram.providers.MazeElementTypes.DecisionsRate_3007);
		case Maze.diagram.edit.parts.StartPointEditPart.VISUAL_ID:
			return getImage("Navigator?Node?geodes.sms.maze?StartPoint", //$NON-NLS-1$
					Maze.diagram.providers.MazeElementTypes.StartPoint_3008);
		case Maze.diagram.edit.parts.EndPointEditPart.VISUAL_ID:
			return getImage("Navigator?Node?geodes.sms.maze?EndPoint", //$NON-NLS-1$
					Maze.diagram.providers.MazeElementTypes.EndPoint_3009);
		case Maze.diagram.edit.parts.DecisionsRate2EditPart.VISUAL_ID:
			return getImage("Navigator?Node?geodes.sms.maze?DecisionsRate", //$NON-NLS-1$
					Maze.diagram.providers.MazeElementTypes.DecisionsRate_3010);
		case Maze.diagram.edit.parts.StraightRate2EditPart.VISUAL_ID:
			return getImage("Navigator?Node?geodes.sms.maze?StraightRate", //$NON-NLS-1$
					Maze.diagram.providers.MazeElementTypes.StraightRate_3011);
		case Maze.diagram.edit.parts.TurnRate2EditPart.VISUAL_ID:
			return getImage("Navigator?Node?geodes.sms.maze?TurnRate", //$NON-NLS-1$
					Maze.diagram.providers.MazeElementTypes.TurnRate_3012);
		case Maze.diagram.edit.parts.EndRateEditPart.VISUAL_ID:
			return getImage("Navigator?Node?geodes.sms.maze?EndRate", //$NON-NLS-1$
					Maze.diagram.providers.MazeElementTypes.EndRate_3013);
		case Maze.diagram.edit.parts.RectangleGeneratorFpgEditPart.VISUAL_ID:
			return getImage("Navigator?Link?geodes.sms.maze?RectangleGenerator?fpg", //$NON-NLS-1$
					Maze.diagram.providers.MazeElementTypes.RectangleGeneratorFpg_4001);
		case Maze.diagram.edit.parts.ForcePatternGeneratorSpgEditPart.VISUAL_ID:
			return getImage("Navigator?Link?geodes.sms.maze?ForcePatternGenerator?spg", //$NON-NLS-1$
					Maze.diagram.providers.MazeElementTypes.ForcePatternGeneratorSpg_4002);
		case Maze.diagram.edit.parts.SolutionPathGeneratorMbgEditPart.VISUAL_ID:
			return getImage("Navigator?Link?geodes.sms.maze?SolutionPathGenerator?mbg", //$NON-NLS-1$
					Maze.diagram.providers.MazeElementTypes.SolutionPathGeneratorMbg_4003);
		}
		return getImage("Navigator?UnknownElement", null); //$NON-NLS-1$
	}

	/**
	* @generated
	*/
	private Image getImage(String key, IElementType elementType) {
		ImageRegistry imageRegistry = Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().getImageRegistry();
		Image image = imageRegistry.get(key);
		if (image == null && elementType != null
				&& Maze.diagram.providers.MazeElementTypes.isKnownElementType(elementType)) {
			image = Maze.diagram.providers.MazeElementTypes.getImage(elementType);
			imageRegistry.put(key, image);
		}

		if (image == null) {
			image = imageRegistry.get("Navigator?ImageNotFound"); //$NON-NLS-1$
			imageRegistry.put(key, image);
		}
		return image;
	}

	/**
	* @generated
	*/
	public String getText(Object element) {
		if (element instanceof Maze.diagram.navigator.MazeNavigatorGroup) {
			Maze.diagram.navigator.MazeNavigatorGroup group = (Maze.diagram.navigator.MazeNavigatorGroup) element;
			return group.getGroupName();
		}

		if (element instanceof Maze.diagram.navigator.MazeNavigatorItem) {
			Maze.diagram.navigator.MazeNavigatorItem navigatorItem = (Maze.diagram.navigator.MazeNavigatorItem) element;
			if (!isOwnView(navigatorItem.getView())) {
				return null;
			}
			return getText(navigatorItem.getView());
		}

		// Due to plugin.xml content will be called only for "own" views
		if (element instanceof IAdaptable) {
			View view = (View) ((IAdaptable) element).getAdapter(View.class);
			if (view != null && isOwnView(view)) {
				return getText(view);
			}
		}

		return super.getText(element);
	}

	/**
	* @generated
	*/
	public String getText(View view) {
		if (view.getElement() != null && view.getElement().eIsProxy()) {
			return getUnresolvedDomainElementProxyText(view);
		}
		switch (Maze.diagram.part.MazeVisualIDRegistry.getVisualID(view)) {
		case Maze.diagram.edit.parts.MazeDiagramEditPart.VISUAL_ID:
			return getMazeDiagram_1000Text(view);
		case Maze.diagram.edit.parts.RectangleGeneratorEditPart.VISUAL_ID:
			return getRectangleGenerator_2001Text(view);
		case Maze.diagram.edit.parts.ForcePatternGeneratorEditPart.VISUAL_ID:
			return getForcePatternGenerator_2002Text(view);
		case Maze.diagram.edit.parts.SolutionPathGeneratorEditPart.VISUAL_ID:
			return getSolutionPathGenerator_2003Text(view);
		case Maze.diagram.edit.parts.MazeBodyGeneratorEditPart.VISUAL_ID:
			return getMazeBodyGenerator_2004Text(view);
		case Maze.diagram.edit.parts.RowCountEditPart.VISUAL_ID:
			return getRowCount_3001Text(view);
		case Maze.diagram.edit.parts.ColumnCountEditPart.VISUAL_ID:
			return getColumnCount_3002Text(view);
		case Maze.diagram.edit.parts.MazeCellEditPart.VISUAL_ID:
			return getMazeCell_3003Text(view);
		case Maze.diagram.edit.parts.CellPointEditPart.VISUAL_ID:
			return getCellPoint_3004Text(view);
		case Maze.diagram.edit.parts.TurnRateEditPart.VISUAL_ID:
			return getTurnRate_3005Text(view);
		case Maze.diagram.edit.parts.StraightRateEditPart.VISUAL_ID:
			return getStraightRate_3006Text(view);
		case Maze.diagram.edit.parts.DecisionsRateEditPart.VISUAL_ID:
			return getDecisionsRate_3007Text(view);
		case Maze.diagram.edit.parts.StartPointEditPart.VISUAL_ID:
			return getStartPoint_3008Text(view);
		case Maze.diagram.edit.parts.EndPointEditPart.VISUAL_ID:
			return getEndPoint_3009Text(view);
		case Maze.diagram.edit.parts.DecisionsRate2EditPart.VISUAL_ID:
			return getDecisionsRate_3010Text(view);
		case Maze.diagram.edit.parts.StraightRate2EditPart.VISUAL_ID:
			return getStraightRate_3011Text(view);
		case Maze.diagram.edit.parts.TurnRate2EditPart.VISUAL_ID:
			return getTurnRate_3012Text(view);
		case Maze.diagram.edit.parts.EndRateEditPart.VISUAL_ID:
			return getEndRate_3013Text(view);
		case Maze.diagram.edit.parts.RectangleGeneratorFpgEditPart.VISUAL_ID:
			return getRectangleGeneratorFpg_4001Text(view);
		case Maze.diagram.edit.parts.ForcePatternGeneratorSpgEditPart.VISUAL_ID:
			return getForcePatternGeneratorSpg_4002Text(view);
		case Maze.diagram.edit.parts.SolutionPathGeneratorMbgEditPart.VISUAL_ID:
			return getSolutionPathGeneratorMbg_4003Text(view);
		}
		return getUnknownElementText(view);
	}

	/**
	* @generated
	*/
	private String getMazeDiagram_1000Text(View view) {
		Maze.MazeDiagram domainModelElement = (Maze.MazeDiagram) view.getElement();
		if (domainModelElement != null) {
			return domainModelElement.getName();
		} else {
			Maze.diagram.part.MazeDiagramEditorPlugin.getInstance()
					.logError("No domain element for view with visualID = " + 1000); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getRectangleGenerator_2001Text(View view) {
		IParser parser = Maze.diagram.providers.MazeParserProvider.getParser(
				Maze.diagram.providers.MazeElementTypes.RectangleGenerator_2001,
				view.getElement() != null ? view.getElement() : view, Maze.diagram.part.MazeVisualIDRegistry
						.getType(Maze.diagram.edit.parts.RectangleGeneratorNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().logError("Parser was not found for label " + 5003); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getForcePatternGenerator_2002Text(View view) {
		IParser parser = Maze.diagram.providers.MazeParserProvider.getParser(
				Maze.diagram.providers.MazeElementTypes.ForcePatternGenerator_2002,
				view.getElement() != null ? view.getElement() : view, Maze.diagram.part.MazeVisualIDRegistry
						.getType(Maze.diagram.edit.parts.ForcePatternGeneratorNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().logError("Parser was not found for label " + 5006); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getSolutionPathGenerator_2003Text(View view) {
		IParser parser = Maze.diagram.providers.MazeParserProvider.getParser(
				Maze.diagram.providers.MazeElementTypes.SolutionPathGenerator_2003,
				view.getElement() != null ? view.getElement() : view, Maze.diagram.part.MazeVisualIDRegistry
						.getType(Maze.diagram.edit.parts.SolutionPathGeneratorNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().logError("Parser was not found for label " + 5012); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getMazeBodyGenerator_2004Text(View view) {
		IParser parser = Maze.diagram.providers.MazeParserProvider.getParser(
				Maze.diagram.providers.MazeElementTypes.MazeBodyGenerator_2004,
				view.getElement() != null ? view.getElement() : view, Maze.diagram.part.MazeVisualIDRegistry
						.getType(Maze.diagram.edit.parts.MazeBodyGeneratorNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().logError("Parser was not found for label " + 5017); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getRowCount_3001Text(View view) {
		IParser parser = Maze.diagram.providers.MazeParserProvider.getParser(
				Maze.diagram.providers.MazeElementTypes.RowCount_3001,
				view.getElement() != null ? view.getElement() : view,
				Maze.diagram.part.MazeVisualIDRegistry.getType(Maze.diagram.edit.parts.RowCountNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().logError("Parser was not found for label " + 5001); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getColumnCount_3002Text(View view) {
		IParser parser = Maze.diagram.providers.MazeParserProvider.getParser(
				Maze.diagram.providers.MazeElementTypes.ColumnCount_3002,
				view.getElement() != null ? view.getElement() : view, Maze.diagram.part.MazeVisualIDRegistry
						.getType(Maze.diagram.edit.parts.ColumnCountNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().logError("Parser was not found for label " + 5002); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getMazeCell_3003Text(View view) {
		IParser parser = Maze.diagram.providers.MazeParserProvider.getParser(
				Maze.diagram.providers.MazeElementTypes.MazeCell_3003,
				view.getElement() != null ? view.getElement() : view,
				Maze.diagram.part.MazeVisualIDRegistry.getType(Maze.diagram.edit.parts.MazeCellTypeEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().logError("Parser was not found for label " + 5005); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getCellPoint_3004Text(View view) {
		IParser parser = Maze.diagram.providers.MazeParserProvider.getParser(
				Maze.diagram.providers.MazeElementTypes.CellPoint_3004,
				view.getElement() != null ? view.getElement() : view, Maze.diagram.part.MazeVisualIDRegistry
						.getType(Maze.diagram.edit.parts.CellPointNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().logError("Parser was not found for label " + 5004); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getTurnRate_3005Text(View view) {
		IParser parser = Maze.diagram.providers.MazeParserProvider.getParser(
				Maze.diagram.providers.MazeElementTypes.TurnRate_3005,
				view.getElement() != null ? view.getElement() : view,
				Maze.diagram.part.MazeVisualIDRegistry.getType(Maze.diagram.edit.parts.TurnRateNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().logError("Parser was not found for label " + 5007); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getStraightRate_3006Text(View view) {
		IParser parser = Maze.diagram.providers.MazeParserProvider.getParser(
				Maze.diagram.providers.MazeElementTypes.StraightRate_3006,
				view.getElement() != null ? view.getElement() : view, Maze.diagram.part.MazeVisualIDRegistry
						.getType(Maze.diagram.edit.parts.StraightRateNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().logError("Parser was not found for label " + 5008); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getDecisionsRate_3007Text(View view) {
		IParser parser = Maze.diagram.providers.MazeParserProvider.getParser(
				Maze.diagram.providers.MazeElementTypes.DecisionsRate_3007,
				view.getElement() != null ? view.getElement() : view, Maze.diagram.part.MazeVisualIDRegistry
						.getType(Maze.diagram.edit.parts.DecisionsRateNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().logError("Parser was not found for label " + 5009); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getStartPoint_3008Text(View view) {
		IParser parser = Maze.diagram.providers.MazeParserProvider.getParser(
				Maze.diagram.providers.MazeElementTypes.StartPoint_3008,
				view.getElement() != null ? view.getElement() : view, Maze.diagram.part.MazeVisualIDRegistry
						.getType(Maze.diagram.edit.parts.StartPointNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().logError("Parser was not found for label " + 5010); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getEndPoint_3009Text(View view) {
		IParser parser = Maze.diagram.providers.MazeParserProvider.getParser(
				Maze.diagram.providers.MazeElementTypes.EndPoint_3009,
				view.getElement() != null ? view.getElement() : view,
				Maze.diagram.part.MazeVisualIDRegistry.getType(Maze.diagram.edit.parts.EndPointNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().logError("Parser was not found for label " + 5011); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getDecisionsRate_3010Text(View view) {
		IParser parser = Maze.diagram.providers.MazeParserProvider.getParser(
				Maze.diagram.providers.MazeElementTypes.DecisionsRate_3010,
				view.getElement() != null ? view.getElement() : view, Maze.diagram.part.MazeVisualIDRegistry
						.getType(Maze.diagram.edit.parts.DecisionsRateName2EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().logError("Parser was not found for label " + 5013); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getStraightRate_3011Text(View view) {
		IParser parser = Maze.diagram.providers.MazeParserProvider.getParser(
				Maze.diagram.providers.MazeElementTypes.StraightRate_3011,
				view.getElement() != null ? view.getElement() : view, Maze.diagram.part.MazeVisualIDRegistry
						.getType(Maze.diagram.edit.parts.StraightRateName2EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().logError("Parser was not found for label " + 5014); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getTurnRate_3012Text(View view) {
		IParser parser = Maze.diagram.providers.MazeParserProvider.getParser(
				Maze.diagram.providers.MazeElementTypes.TurnRate_3012,
				view.getElement() != null ? view.getElement() : view, Maze.diagram.part.MazeVisualIDRegistry
						.getType(Maze.diagram.edit.parts.TurnRateName2EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().logError("Parser was not found for label " + 5015); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getEndRate_3013Text(View view) {
		IParser parser = Maze.diagram.providers.MazeParserProvider.getParser(
				Maze.diagram.providers.MazeElementTypes.EndRate_3013,
				view.getElement() != null ? view.getElement() : view,
				Maze.diagram.part.MazeVisualIDRegistry.getType(Maze.diagram.edit.parts.EndRateNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().logError("Parser was not found for label " + 5016); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getRectangleGeneratorFpg_4001Text(View view) {
		IParser parser = Maze.diagram.providers.MazeParserProvider.getParser(
				Maze.diagram.providers.MazeElementTypes.RectangleGeneratorFpg_4001,
				view.getElement() != null ? view.getElement() : view, CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().logError("Parser was not found for label " + 6001); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getForcePatternGeneratorSpg_4002Text(View view) {
		IParser parser = Maze.diagram.providers.MazeParserProvider.getParser(
				Maze.diagram.providers.MazeElementTypes.ForcePatternGeneratorSpg_4002,
				view.getElement() != null ? view.getElement() : view, CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().logError("Parser was not found for label " + 6002); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getSolutionPathGeneratorMbg_4003Text(View view) {
		IParser parser = Maze.diagram.providers.MazeParserProvider.getParser(
				Maze.diagram.providers.MazeElementTypes.SolutionPathGeneratorMbg_4003,
				view.getElement() != null ? view.getElement() : view, CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().logError("Parser was not found for label " + 6003); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getUnknownElementText(View view) {
		return "<UnknownElement Visual_ID = " + view.getType() + ">"; //$NON-NLS-1$  //$NON-NLS-2$
	}

	/**
	* @generated
	*/
	private String getUnresolvedDomainElementProxyText(View view) {
		return "<Unresolved domain element Visual_ID = " + view.getType() + ">"; //$NON-NLS-1$  //$NON-NLS-2$
	}

	/**
	* @generated
	*/
	public void init(ICommonContentExtensionSite aConfig) {
	}

	/**
	* @generated
	*/
	public void restoreState(IMemento aMemento) {
	}

	/**
	* @generated
	*/
	public void saveState(IMemento aMemento) {
	}

	/**
	* @generated
	*/
	public String getDescription(Object anElement) {
		return null;
	}

	/**
	* @generated
	*/
	private boolean isOwnView(View view) {
		return Maze.diagram.edit.parts.MazeDiagramEditPart.MODEL_ID
				.equals(Maze.diagram.part.MazeVisualIDRegistry.getModelID(view));
	}

}
