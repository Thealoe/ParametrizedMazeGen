/*
* 
*/
package Maze.diagram.navigator;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.edit.domain.AdapterFactoryEditingDomain;
import org.eclipse.emf.transaction.TransactionalEditingDomain;
import org.eclipse.emf.workspace.util.WorkspaceSynchronizer;
import org.eclipse.gmf.runtime.emf.core.GMFEditingDomainFactory;
import org.eclipse.gmf.runtime.notation.Diagram;
import org.eclipse.gmf.runtime.notation.Edge;
import org.eclipse.gmf.runtime.notation.Node;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.ui.IMemento;
import org.eclipse.ui.navigator.ICommonContentExtensionSite;
import org.eclipse.ui.navigator.ICommonContentProvider;

/**
 * @generated
 */
public class MazeNavigatorContentProvider implements ICommonContentProvider {

	/**
	* @generated
	*/
	private static final Object[] EMPTY_ARRAY = new Object[0];

	/**
	* @generated
	*/
	private Viewer myViewer;

	/**
	* @generated
	*/
	private AdapterFactoryEditingDomain myEditingDomain;

	/**
	* @generated
	*/
	private WorkspaceSynchronizer myWorkspaceSynchronizer;

	/**
	* @generated
	*/
	private Runnable myViewerRefreshRunnable;

	/**
	* @generated
	*/
	@SuppressWarnings({ "unchecked", "serial", "rawtypes" })
	public MazeNavigatorContentProvider() {
		TransactionalEditingDomain editingDomain = GMFEditingDomainFactory.INSTANCE.createEditingDomain();
		myEditingDomain = (AdapterFactoryEditingDomain) editingDomain;
		myEditingDomain.setResourceToReadOnlyMap(new HashMap() {
			public Object get(Object key) {
				if (!containsKey(key)) {
					put(key, Boolean.TRUE);
				}
				return super.get(key);
			}
		});
		myViewerRefreshRunnable = new Runnable() {
			public void run() {
				if (myViewer != null) {
					myViewer.refresh();
				}
			}
		};
		myWorkspaceSynchronizer = new WorkspaceSynchronizer(editingDomain, new WorkspaceSynchronizer.Delegate() {
			public void dispose() {
			}

			public boolean handleResourceChanged(final Resource resource) {
				unloadAllResources();
				asyncRefresh();
				return true;
			}

			public boolean handleResourceDeleted(Resource resource) {
				unloadAllResources();
				asyncRefresh();
				return true;
			}

			public boolean handleResourceMoved(Resource resource, final URI newURI) {
				unloadAllResources();
				asyncRefresh();
				return true;
			}
		});
	}

	/**
	* @generated
	*/
	public void dispose() {
		myWorkspaceSynchronizer.dispose();
		myWorkspaceSynchronizer = null;
		myViewerRefreshRunnable = null;
		myViewer = null;
		unloadAllResources();
		((TransactionalEditingDomain) myEditingDomain).dispose();
		myEditingDomain = null;
	}

	/**
	* @generated
	*/
	public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
		myViewer = viewer;
	}

	/**
	* @generated
	*/
	void unloadAllResources() {
		for (Resource nextResource : myEditingDomain.getResourceSet().getResources()) {
			nextResource.unload();
		}
	}

	/**
	* @generated
	*/
	void asyncRefresh() {
		if (myViewer != null && !myViewer.getControl().isDisposed()) {
			myViewer.getControl().getDisplay().asyncExec(myViewerRefreshRunnable);
		}
	}

	/**
	* @generated
	*/
	public Object[] getElements(Object inputElement) {
		return getChildren(inputElement);
	}

	/**
	* @generated
	*/
	public void restoreState(IMemento aMemento) {
	}

	/**
	 * @generated
	 */
	public void saveState(IMemento aMemento) {
	}

	/**
	* @generated
	*/
	public void init(ICommonContentExtensionSite aConfig) {
	}

	/**
	* @generated
	*/
	public Object[] getChildren(Object parentElement) {
		if (parentElement instanceof IFile) {
			IFile file = (IFile) parentElement;
			URI fileURI = URI.createPlatformResourceURI(file.getFullPath().toString(), true);
			Resource resource = myEditingDomain.getResourceSet().getResource(fileURI, true);
			ArrayList<Maze.diagram.navigator.MazeNavigatorItem> result = new ArrayList<Maze.diagram.navigator.MazeNavigatorItem>();
			ArrayList<View> topViews = new ArrayList<View>(resource.getContents().size());
			for (EObject o : resource.getContents()) {
				if (o instanceof View) {
					topViews.add((View) o);
				}
			}
			result.addAll(createNavigatorItems(
					selectViewsByType(topViews, Maze.diagram.edit.parts.MazeDiagramEditPart.MODEL_ID), file, false));
			return result.toArray();
		}

		if (parentElement instanceof Maze.diagram.navigator.MazeNavigatorGroup) {
			Maze.diagram.navigator.MazeNavigatorGroup group = (Maze.diagram.navigator.MazeNavigatorGroup) parentElement;
			return group.getChildren();
		}

		if (parentElement instanceof Maze.diagram.navigator.MazeNavigatorItem) {
			Maze.diagram.navigator.MazeNavigatorItem navigatorItem = (Maze.diagram.navigator.MazeNavigatorItem) parentElement;
			if (navigatorItem.isLeaf() || !isOwnView(navigatorItem.getView())) {
				return EMPTY_ARRAY;
			}
			return getViewChildren(navigatorItem.getView(), parentElement);
		}

		/*
		* Due to plugin.xml restrictions this code will be called only for views representing
		* shortcuts to this diagram elements created on other diagrams. 
		*/
		if (parentElement instanceof IAdaptable) {
			View view = (View) ((IAdaptable) parentElement).getAdapter(View.class);
			if (view != null) {
				return getViewChildren(view, parentElement);
			}
		}

		return EMPTY_ARRAY;
	}

	/**
	* @generated
	*/
	private Object[] getViewChildren(View view, Object parentElement) {
		switch (Maze.diagram.part.MazeVisualIDRegistry.getVisualID(view)) {

		case Maze.diagram.edit.parts.MazeDiagramEditPart.VISUAL_ID: {
			LinkedList<Maze.diagram.navigator.MazeAbstractNavigatorItem> result = new LinkedList<Maze.diagram.navigator.MazeAbstractNavigatorItem>();
			result.addAll(getForeignShortcuts((Diagram) view, parentElement));
			Diagram sv = (Diagram) view;
			Maze.diagram.navigator.MazeNavigatorGroup links = new Maze.diagram.navigator.MazeNavigatorGroup(
					Maze.diagram.part.Messages.NavigatorGroupName_MazeDiagram_1000_links,
					"icons/linksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getChildrenByType(Collections.singleton(sv), Maze.diagram.part.MazeVisualIDRegistry
					.getType(Maze.diagram.edit.parts.StackMazeBodyGeneratorEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv), Maze.diagram.part.MazeVisualIDRegistry
					.getType(Maze.diagram.edit.parts.RandomMazeBodyGeneratorEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv), Maze.diagram.part.MazeVisualIDRegistry
					.getType(Maze.diagram.edit.parts.RectangleGeneratorEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv), Maze.diagram.part.MazeVisualIDRegistry
					.getType(Maze.diagram.edit.parts.SolutionPathGeneratorEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getDiagramLinksByType(Collections.singleton(sv), Maze.diagram.part.MazeVisualIDRegistry
					.getType(Maze.diagram.edit.parts.RectangleGeneratorSpgEditPart.VISUAL_ID));
			links.addChildren(createNavigatorItems(connectedViews, links, false));
			connectedViews = getDiagramLinksByType(Collections.singleton(sv), Maze.diagram.part.MazeVisualIDRegistry
					.getType(Maze.diagram.edit.parts.SolutionPathGeneratorMbgEditPart.VISUAL_ID));
			links.addChildren(createNavigatorItems(connectedViews, links, false));
			if (!links.isEmpty()) {
				result.add(links);
			}
			return result.toArray();
		}

		case Maze.diagram.edit.parts.RectangleGeneratorEditPart.VISUAL_ID: {
			LinkedList<Maze.diagram.navigator.MazeAbstractNavigatorItem> result = new LinkedList<Maze.diagram.navigator.MazeAbstractNavigatorItem>();
			Node sv = (Node) view;
			Maze.diagram.navigator.MazeNavigatorGroup outgoinglinks = new Maze.diagram.navigator.MazeNavigatorGroup(
					Maze.diagram.part.Messages.NavigatorGroupName_RectangleGenerator_2003_outgoinglinks,
					"icons/outgoingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getChildrenByType(Collections.singleton(sv),
					Maze.diagram.part.MazeVisualIDRegistry.getType(
							Maze.diagram.edit.parts.RectangleGeneratorRectangleGeneratorRcCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews,
					Maze.diagram.part.MazeVisualIDRegistry.getType(Maze.diagram.edit.parts.RowCountEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					Maze.diagram.part.MazeVisualIDRegistry.getType(
							Maze.diagram.edit.parts.RectangleGeneratorRectangleGeneratorCcCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, Maze.diagram.part.MazeVisualIDRegistry
					.getType(Maze.diagram.edit.parts.ColumnCountEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv), Maze.diagram.part.MazeVisualIDRegistry
					.getType(Maze.diagram.edit.parts.RectangleGeneratorSpgEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			if (!outgoinglinks.isEmpty()) {
				result.add(outgoinglinks);
			}
			return result.toArray();
		}

		case Maze.diagram.edit.parts.SolutionPathGeneratorEditPart.VISUAL_ID: {
			LinkedList<Maze.diagram.navigator.MazeAbstractNavigatorItem> result = new LinkedList<Maze.diagram.navigator.MazeAbstractNavigatorItem>();
			Node sv = (Node) view;
			Maze.diagram.navigator.MazeNavigatorGroup incominglinks = new Maze.diagram.navigator.MazeNavigatorGroup(
					Maze.diagram.part.Messages.NavigatorGroupName_SolutionPathGenerator_2004_incominglinks,
					"icons/incomingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Maze.diagram.navigator.MazeNavigatorGroup outgoinglinks = new Maze.diagram.navigator.MazeNavigatorGroup(
					Maze.diagram.part.Messages.NavigatorGroupName_SolutionPathGenerator_2004_outgoinglinks,
					"icons/outgoingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getChildrenByType(Collections.singleton(sv),
					Maze.diagram.part.MazeVisualIDRegistry.getType(
							Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorTrCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, Maze.diagram.part.MazeVisualIDRegistry
					.getType(Maze.diagram.edit.parts.TurnRate2EditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					Maze.diagram.part.MazeVisualIDRegistry.getType(
							Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorSrCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, Maze.diagram.part.MazeVisualIDRegistry
					.getType(Maze.diagram.edit.parts.StraightRate2EditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					Maze.diagram.part.MazeVisualIDRegistry.getType(
							Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorDrCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, Maze.diagram.part.MazeVisualIDRegistry
					.getType(Maze.diagram.edit.parts.DecisionsRate2EditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					Maze.diagram.part.MazeVisualIDRegistry.getType(
							Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorSpCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, Maze.diagram.part.MazeVisualIDRegistry
					.getType(Maze.diagram.edit.parts.StartPointEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					Maze.diagram.part.MazeVisualIDRegistry.getType(
							Maze.diagram.edit.parts.SolutionPathGeneratorSolutionPathGeneratorEpCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews,
					Maze.diagram.part.MazeVisualIDRegistry.getType(Maze.diagram.edit.parts.EndPointEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getIncomingLinksByType(Collections.singleton(sv), Maze.diagram.part.MazeVisualIDRegistry
					.getType(Maze.diagram.edit.parts.RectangleGeneratorSpgEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv), Maze.diagram.part.MazeVisualIDRegistry
					.getType(Maze.diagram.edit.parts.SolutionPathGeneratorMbgEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			if (!incominglinks.isEmpty()) {
				result.add(incominglinks);
			}
			if (!outgoinglinks.isEmpty()) {
				result.add(outgoinglinks);
			}
			return result.toArray();
		}

		case Maze.diagram.edit.parts.StackMazeBodyGeneratorEditPart.VISUAL_ID: {
			LinkedList<Maze.diagram.navigator.MazeAbstractNavigatorItem> result = new LinkedList<Maze.diagram.navigator.MazeAbstractNavigatorItem>();
			Node sv = (Node) view;
			Maze.diagram.navigator.MazeNavigatorGroup incominglinks = new Maze.diagram.navigator.MazeNavigatorGroup(
					Maze.diagram.part.Messages.NavigatorGroupName_StackMazeBodyGenerator_2005_incominglinks,
					"icons/incomingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getChildrenByType(Collections.singleton(sv),
					Maze.diagram.part.MazeVisualIDRegistry.getType(
							Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorDrCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, Maze.diagram.part.MazeVisualIDRegistry
					.getType(Maze.diagram.edit.parts.DecisionsRateEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					Maze.diagram.part.MazeVisualIDRegistry.getType(
							Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorSrCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, Maze.diagram.part.MazeVisualIDRegistry
					.getType(Maze.diagram.edit.parts.StraightRateEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					Maze.diagram.part.MazeVisualIDRegistry.getType(
							Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorTrCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews,
					Maze.diagram.part.MazeVisualIDRegistry.getType(Maze.diagram.edit.parts.TurnRateEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					Maze.diagram.part.MazeVisualIDRegistry.getType(
							Maze.diagram.edit.parts.StackMazeBodyGeneratorStackMazeBodyGeneratorErCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews,
					Maze.diagram.part.MazeVisualIDRegistry.getType(Maze.diagram.edit.parts.EndRateEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getIncomingLinksByType(Collections.singleton(sv), Maze.diagram.part.MazeVisualIDRegistry
					.getType(Maze.diagram.edit.parts.SolutionPathGeneratorMbgEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			if (!incominglinks.isEmpty()) {
				result.add(incominglinks);
			}
			return result.toArray();
		}

		case Maze.diagram.edit.parts.RandomMazeBodyGeneratorEditPart.VISUAL_ID: {
			LinkedList<Maze.diagram.navigator.MazeAbstractNavigatorItem> result = new LinkedList<Maze.diagram.navigator.MazeAbstractNavigatorItem>();
			Node sv = (Node) view;
			Maze.diagram.navigator.MazeNavigatorGroup incominglinks = new Maze.diagram.navigator.MazeNavigatorGroup(
					Maze.diagram.part.Messages.NavigatorGroupName_RandomMazeBodyGenerator_2006_incominglinks,
					"icons/incomingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getChildrenByType(Collections.singleton(sv),
					Maze.diagram.part.MazeVisualIDRegistry.getType(
							Maze.diagram.edit.parts.RandomMazeBodyGeneratorRandomMazeBodyGeneratorDrCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, Maze.diagram.part.MazeVisualIDRegistry
					.getType(Maze.diagram.edit.parts.DecisionsRateEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					Maze.diagram.part.MazeVisualIDRegistry.getType(
							Maze.diagram.edit.parts.RandomMazeBodyGeneratorRandomMazeBodyGeneratorSrCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, Maze.diagram.part.MazeVisualIDRegistry
					.getType(Maze.diagram.edit.parts.StraightRateEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					Maze.diagram.part.MazeVisualIDRegistry.getType(
							Maze.diagram.edit.parts.RandomMazeBodyGeneratorRandomMazeBodyGeneratorTrCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews,
					Maze.diagram.part.MazeVisualIDRegistry.getType(Maze.diagram.edit.parts.TurnRateEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					Maze.diagram.part.MazeVisualIDRegistry.getType(
							Maze.diagram.edit.parts.RandomMazeBodyGeneratorRandomMazeBodyGeneratorErCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews,
					Maze.diagram.part.MazeVisualIDRegistry.getType(Maze.diagram.edit.parts.EndRateEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getIncomingLinksByType(Collections.singleton(sv), Maze.diagram.part.MazeVisualIDRegistry
					.getType(Maze.diagram.edit.parts.SolutionPathGeneratorMbgEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			if (!incominglinks.isEmpty()) {
				result.add(incominglinks);
			}
			return result.toArray();
		}

		case Maze.diagram.edit.parts.RectangleGeneratorSpgEditPart.VISUAL_ID: {
			LinkedList<Maze.diagram.navigator.MazeAbstractNavigatorItem> result = new LinkedList<Maze.diagram.navigator.MazeAbstractNavigatorItem>();
			Edge sv = (Edge) view;
			Maze.diagram.navigator.MazeNavigatorGroup target = new Maze.diagram.navigator.MazeNavigatorGroup(
					Maze.diagram.part.Messages.NavigatorGroupName_RectangleGeneratorSpg_4001_target,
					"icons/linkTargetNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Maze.diagram.navigator.MazeNavigatorGroup source = new Maze.diagram.navigator.MazeNavigatorGroup(
					Maze.diagram.part.Messages.NavigatorGroupName_RectangleGeneratorSpg_4001_source,
					"icons/linkSourceNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getLinksTargetByType(Collections.singleton(sv), Maze.diagram.part.MazeVisualIDRegistry
					.getType(Maze.diagram.edit.parts.SolutionPathGeneratorEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv), Maze.diagram.part.MazeVisualIDRegistry
					.getType(Maze.diagram.edit.parts.RectangleGeneratorEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			if (!target.isEmpty()) {
				result.add(target);
			}
			if (!source.isEmpty()) {
				result.add(source);
			}
			return result.toArray();
		}

		case Maze.diagram.edit.parts.SolutionPathGeneratorMbgEditPart.VISUAL_ID: {
			LinkedList<Maze.diagram.navigator.MazeAbstractNavigatorItem> result = new LinkedList<Maze.diagram.navigator.MazeAbstractNavigatorItem>();
			Edge sv = (Edge) view;
			Maze.diagram.navigator.MazeNavigatorGroup target = new Maze.diagram.navigator.MazeNavigatorGroup(
					Maze.diagram.part.Messages.NavigatorGroupName_SolutionPathGeneratorMbg_4002_target,
					"icons/linkTargetNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Maze.diagram.navigator.MazeNavigatorGroup source = new Maze.diagram.navigator.MazeNavigatorGroup(
					Maze.diagram.part.Messages.NavigatorGroupName_SolutionPathGeneratorMbg_4002_source,
					"icons/linkSourceNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getLinksTargetByType(Collections.singleton(sv), Maze.diagram.part.MazeVisualIDRegistry
					.getType(Maze.diagram.edit.parts.StackMazeBodyGeneratorEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksTargetByType(Collections.singleton(sv), Maze.diagram.part.MazeVisualIDRegistry
					.getType(Maze.diagram.edit.parts.RandomMazeBodyGeneratorEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv), Maze.diagram.part.MazeVisualIDRegistry
					.getType(Maze.diagram.edit.parts.SolutionPathGeneratorEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			if (!target.isEmpty()) {
				result.add(target);
			}
			if (!source.isEmpty()) {
				result.add(source);
			}
			return result.toArray();
		}
		}
		return EMPTY_ARRAY;
	}

	/**
	* @generated
	*/
	private Collection<View> getLinksSourceByType(Collection<Edge> edges, String type) {
		LinkedList<View> result = new LinkedList<View>();
		for (Edge nextEdge : edges) {
			View nextEdgeSource = nextEdge.getSource();
			if (type.equals(nextEdgeSource.getType()) && isOwnView(nextEdgeSource)) {
				result.add(nextEdgeSource);
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private Collection<View> getLinksTargetByType(Collection<Edge> edges, String type) {
		LinkedList<View> result = new LinkedList<View>();
		for (Edge nextEdge : edges) {
			View nextEdgeTarget = nextEdge.getTarget();
			if (type.equals(nextEdgeTarget.getType()) && isOwnView(nextEdgeTarget)) {
				result.add(nextEdgeTarget);
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private Collection<View> getOutgoingLinksByType(Collection<? extends View> nodes, String type) {
		LinkedList<View> result = new LinkedList<View>();
		for (View nextNode : nodes) {
			result.addAll(selectViewsByType(nextNode.getSourceEdges(), type));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private Collection<View> getIncomingLinksByType(Collection<? extends View> nodes, String type) {
		LinkedList<View> result = new LinkedList<View>();
		for (View nextNode : nodes) {
			result.addAll(selectViewsByType(nextNode.getTargetEdges(), type));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private Collection<View> getChildrenByType(Collection<? extends View> nodes, String type) {
		LinkedList<View> result = new LinkedList<View>();
		for (View nextNode : nodes) {
			result.addAll(selectViewsByType(nextNode.getChildren(), type));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private Collection<View> getDiagramLinksByType(Collection<Diagram> diagrams, String type) {
		ArrayList<View> result = new ArrayList<View>();
		for (Diagram nextDiagram : diagrams) {
			result.addAll(selectViewsByType(nextDiagram.getEdges(), type));
		}
		return result;
	}

	// TODO refactor as static method
	/**
	 * @generated
	 */
	private Collection<View> selectViewsByType(Collection<View> views, String type) {
		ArrayList<View> result = new ArrayList<View>();
		for (View nextView : views) {
			if (type.equals(nextView.getType()) && isOwnView(nextView)) {
				result.add(nextView);
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private boolean isOwnView(View view) {
		return Maze.diagram.edit.parts.MazeDiagramEditPart.MODEL_ID
				.equals(Maze.diagram.part.MazeVisualIDRegistry.getModelID(view));
	}

	/**
	 * @generated
	 */
	private Collection<Maze.diagram.navigator.MazeNavigatorItem> createNavigatorItems(Collection<View> views,
			Object parent, boolean isLeafs) {
		ArrayList<Maze.diagram.navigator.MazeNavigatorItem> result = new ArrayList<Maze.diagram.navigator.MazeNavigatorItem>(
				views.size());
		for (View nextView : views) {
			result.add(new Maze.diagram.navigator.MazeNavigatorItem(nextView, parent, isLeafs));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private Collection<Maze.diagram.navigator.MazeNavigatorItem> getForeignShortcuts(Diagram diagram, Object parent) {
		LinkedList<View> result = new LinkedList<View>();
		for (Iterator<View> it = diagram.getChildren().iterator(); it.hasNext();) {
			View nextView = it.next();
			if (!isOwnView(nextView) && nextView.getEAnnotation("Shortcut") != null) { //$NON-NLS-1$
				result.add(nextView);
			}
		}
		return createNavigatorItems(result, parent, false);
	}

	/**
	* @generated
	*/
	public Object getParent(Object element) {
		if (element instanceof Maze.diagram.navigator.MazeAbstractNavigatorItem) {
			Maze.diagram.navigator.MazeAbstractNavigatorItem abstractNavigatorItem = (Maze.diagram.navigator.MazeAbstractNavigatorItem) element;
			return abstractNavigatorItem.getParent();
		}
		return null;
	}

	/**
	* @generated
	*/
	public boolean hasChildren(Object element) {
		return element instanceof IFile || getChildren(element).length > 0;
	}

}
