/*
 * 
 */
package Maze.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.AppearancePreferencePage;

/**
 * @generated
 */
public class DiagramAppearancePreferencePage extends AppearancePreferencePage {

	/**
	* @generated
	*/
	public DiagramAppearancePreferencePage() {
		setPreferenceStore(Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
