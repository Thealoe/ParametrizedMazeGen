/*
 * 
 */
package Maze.diagram.preferences;

import org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer;
import org.eclipse.jface.preference.IPreferenceStore;

/**
 * @generated
 */
public class DiagramPreferenceInitializer extends AbstractPreferenceInitializer {

	/**
	* @generated
	*/
	public void initializeDefaultPreferences() {
		IPreferenceStore store = getPreferenceStore();
		Maze.diagram.preferences.DiagramGeneralPreferencePage.initDefaults(store);
		Maze.diagram.preferences.DiagramAppearancePreferencePage.initDefaults(store);
		Maze.diagram.preferences.DiagramConnectionsPreferencePage.initDefaults(store);
		Maze.diagram.preferences.DiagramPrintingPreferencePage.initDefaults(store);
		Maze.diagram.preferences.DiagramRulersAndGridPreferencePage.initDefaults(store);

	}

	/**
	* @generated
	*/
	protected IPreferenceStore getPreferenceStore() {
		return Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().getPreferenceStore();
	}
}
