/*
 * 
 */
package Maze.diagram.providers;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.common.core.service.AbstractProvider;
import org.eclipse.gmf.runtime.common.core.service.IOperation;
import org.eclipse.gmf.runtime.common.ui.services.parser.GetParserOperation;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParser;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParserProvider;
import org.eclipse.gmf.runtime.common.ui.services.parser.ParserService;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.emf.ui.services.parser.ParserHintAdapter;
import org.eclipse.gmf.runtime.notation.View;

/**
 * @generated
 */
public class MazeParserProvider extends AbstractProvider implements IParserProvider {

	/**
	* @generated
	*/
	private IParser stackMazeBodyGeneratorType_name_5013Parser;

	/**
	* @generated
	*/
	private IParser getStackMazeBodyGeneratorType_name_5013Parser() {
		if (stackMazeBodyGeneratorType_name_5013Parser == null) {
			EAttribute[] features = new EAttribute[] {
					Maze.MazePackage.eINSTANCE.getStackMazeBodyGenerator_Type_name() };
			Maze.diagram.parsers.MessageFormatParser parser = new Maze.diagram.parsers.MessageFormatParser(features);
			stackMazeBodyGeneratorType_name_5013Parser = parser;
		}
		return stackMazeBodyGeneratorType_name_5013Parser;
	}

	/**
	* @generated
	*/
	private IParser randomMazeBodyGeneratorType_name_5014Parser;

	/**
	* @generated
	*/
	private IParser getRandomMazeBodyGeneratorType_name_5014Parser() {
		if (randomMazeBodyGeneratorType_name_5014Parser == null) {
			EAttribute[] features = new EAttribute[] {
					Maze.MazePackage.eINSTANCE.getRandomMazeBodyGenerator_Type_name() };
			Maze.diagram.parsers.MessageFormatParser parser = new Maze.diagram.parsers.MessageFormatParser(features);
			randomMazeBodyGeneratorType_name_5014Parser = parser;
		}
		return randomMazeBodyGeneratorType_name_5014Parser;
	}

	/**
	* @generated
	*/
	private IParser rectangleGeneratorName_5008Parser;

	/**
	* @generated
	*/
	private IParser getRectangleGeneratorName_5008Parser() {
		if (rectangleGeneratorName_5008Parser == null) {
			EAttribute[] features = new EAttribute[] { Maze.MazePackage.eINSTANCE.getRectangleGenerator_Name() };
			Maze.diagram.parsers.MessageFormatParser parser = new Maze.diagram.parsers.MessageFormatParser(features);
			rectangleGeneratorName_5008Parser = parser;
		}
		return rectangleGeneratorName_5008Parser;
	}

	/**
	* @generated
	*/
	private IParser solutionPathGeneratorName_5012Parser;

	/**
	* @generated
	*/
	private IParser getSolutionPathGeneratorName_5012Parser() {
		if (solutionPathGeneratorName_5012Parser == null) {
			EAttribute[] features = new EAttribute[] { Maze.MazePackage.eINSTANCE.getSolutionPathGenerator_Name() };
			Maze.diagram.parsers.MessageFormatParser parser = new Maze.diagram.parsers.MessageFormatParser(features);
			solutionPathGeneratorName_5012Parser = parser;
		}
		return solutionPathGeneratorName_5012Parser;
	}

	/**
	* @generated
	*/
	private IParser decisionsRateName_5001Parser;

	/**
	* @generated
	*/
	private IParser getDecisionsRateName_5001Parser() {
		if (decisionsRateName_5001Parser == null) {
			EAttribute[] features = new EAttribute[] { Maze.MazePackage.eINSTANCE.getDecisionsRate_Name() };
			Maze.diagram.parsers.MessageFormatParser parser = new Maze.diagram.parsers.MessageFormatParser(features);
			decisionsRateName_5001Parser = parser;
		}
		return decisionsRateName_5001Parser;
	}

	/**
	* @generated
	*/
	private IParser straightRateName_5002Parser;

	/**
	* @generated
	*/
	private IParser getStraightRateName_5002Parser() {
		if (straightRateName_5002Parser == null) {
			EAttribute[] features = new EAttribute[] { Maze.MazePackage.eINSTANCE.getStraightRate_Name() };
			Maze.diagram.parsers.MessageFormatParser parser = new Maze.diagram.parsers.MessageFormatParser(features);
			straightRateName_5002Parser = parser;
		}
		return straightRateName_5002Parser;
	}

	/**
	* @generated
	*/
	private IParser turnRateName_5003Parser;

	/**
	* @generated
	*/
	private IParser getTurnRateName_5003Parser() {
		if (turnRateName_5003Parser == null) {
			EAttribute[] features = new EAttribute[] { Maze.MazePackage.eINSTANCE.getTurnRate_Name() };
			Maze.diagram.parsers.MessageFormatParser parser = new Maze.diagram.parsers.MessageFormatParser(features);
			turnRateName_5003Parser = parser;
		}
		return turnRateName_5003Parser;
	}

	/**
	* @generated
	*/
	private IParser endRateName_5015Parser;

	/**
	* @generated
	*/
	private IParser getEndRateName_5015Parser() {
		if (endRateName_5015Parser == null) {
			EAttribute[] features = new EAttribute[] { Maze.MazePackage.eINSTANCE.getEndRate_Name() };
			Maze.diagram.parsers.MessageFormatParser parser = new Maze.diagram.parsers.MessageFormatParser(features);
			endRateName_5015Parser = parser;
		}
		return endRateName_5015Parser;
	}

	/**
	* @generated
	*/
	private IParser rowCountName_5006Parser;

	/**
	* @generated
	*/
	private IParser getRowCountName_5006Parser() {
		if (rowCountName_5006Parser == null) {
			EAttribute[] features = new EAttribute[] { Maze.MazePackage.eINSTANCE.getRowCount_Name() };
			Maze.diagram.parsers.MessageFormatParser parser = new Maze.diagram.parsers.MessageFormatParser(features);
			rowCountName_5006Parser = parser;
		}
		return rowCountName_5006Parser;
	}

	/**
	* @generated
	*/
	private IParser columnCountName_5007Parser;

	/**
	* @generated
	*/
	private IParser getColumnCountName_5007Parser() {
		if (columnCountName_5007Parser == null) {
			EAttribute[] features = new EAttribute[] { Maze.MazePackage.eINSTANCE.getColumnCount_Name() };
			Maze.diagram.parsers.MessageFormatParser parser = new Maze.diagram.parsers.MessageFormatParser(features);
			columnCountName_5007Parser = parser;
		}
		return columnCountName_5007Parser;
	}

	/**
	* @generated
	*/
	private IParser turnRateName_5009Parser;

	/**
	* @generated
	*/
	private IParser getTurnRateName_5009Parser() {
		if (turnRateName_5009Parser == null) {
			EAttribute[] features = new EAttribute[] { Maze.MazePackage.eINSTANCE.getTurnRate_Name() };
			Maze.diagram.parsers.MessageFormatParser parser = new Maze.diagram.parsers.MessageFormatParser(features);
			turnRateName_5009Parser = parser;
		}
		return turnRateName_5009Parser;
	}

	/**
	* @generated
	*/
	private IParser straightRateName_5010Parser;

	/**
	* @generated
	*/
	private IParser getStraightRateName_5010Parser() {
		if (straightRateName_5010Parser == null) {
			EAttribute[] features = new EAttribute[] { Maze.MazePackage.eINSTANCE.getStraightRate_Name() };
			Maze.diagram.parsers.MessageFormatParser parser = new Maze.diagram.parsers.MessageFormatParser(features);
			straightRateName_5010Parser = parser;
		}
		return straightRateName_5010Parser;
	}

	/**
	* @generated
	*/
	private IParser decisionsRateName_5011Parser;

	/**
	* @generated
	*/
	private IParser getDecisionsRateName_5011Parser() {
		if (decisionsRateName_5011Parser == null) {
			EAttribute[] features = new EAttribute[] { Maze.MazePackage.eINSTANCE.getDecisionsRate_Name() };
			Maze.diagram.parsers.MessageFormatParser parser = new Maze.diagram.parsers.MessageFormatParser(features);
			decisionsRateName_5011Parser = parser;
		}
		return decisionsRateName_5011Parser;
	}

	/**
	* @generated
	*/
	private IParser startPointName_5016Parser;

	/**
	* @generated
	*/
	private IParser getStartPointName_5016Parser() {
		if (startPointName_5016Parser == null) {
			EAttribute[] features = new EAttribute[] { Maze.MazePackage.eINSTANCE.getStartPoint_Name() };
			Maze.diagram.parsers.MessageFormatParser parser = new Maze.diagram.parsers.MessageFormatParser(features);
			startPointName_5016Parser = parser;
		}
		return startPointName_5016Parser;
	}

	/**
	* @generated
	*/
	private IParser endPointName_5017Parser;

	/**
	* @generated
	*/
	private IParser getEndPointName_5017Parser() {
		if (endPointName_5017Parser == null) {
			EAttribute[] features = new EAttribute[] { Maze.MazePackage.eINSTANCE.getEndPoint_Name() };
			Maze.diagram.parsers.MessageFormatParser parser = new Maze.diagram.parsers.MessageFormatParser(features);
			endPointName_5017Parser = parser;
		}
		return endPointName_5017Parser;
	}

	/**
	* @generated
	*/
	protected IParser getParser(int visualID) {
		switch (visualID) {
		case Maze.diagram.edit.parts.StackMazeBodyGeneratorType_nameEditPart.VISUAL_ID:
			return getStackMazeBodyGeneratorType_name_5013Parser();
		case Maze.diagram.edit.parts.RandomMazeBodyGeneratorType_nameEditPart.VISUAL_ID:
			return getRandomMazeBodyGeneratorType_name_5014Parser();
		case Maze.diagram.edit.parts.RectangleGeneratorNameEditPart.VISUAL_ID:
			return getRectangleGeneratorName_5008Parser();
		case Maze.diagram.edit.parts.SolutionPathGeneratorNameEditPart.VISUAL_ID:
			return getSolutionPathGeneratorName_5012Parser();
		case Maze.diagram.edit.parts.DecisionsRateNameEditPart.VISUAL_ID:
			return getDecisionsRateName_5001Parser();
		case Maze.diagram.edit.parts.StraightRateNameEditPart.VISUAL_ID:
			return getStraightRateName_5002Parser();
		case Maze.diagram.edit.parts.TurnRateNameEditPart.VISUAL_ID:
			return getTurnRateName_5003Parser();
		case Maze.diagram.edit.parts.EndRateNameEditPart.VISUAL_ID:
			return getEndRateName_5015Parser();
		case Maze.diagram.edit.parts.RowCountNameEditPart.VISUAL_ID:
			return getRowCountName_5006Parser();
		case Maze.diagram.edit.parts.ColumnCountNameEditPart.VISUAL_ID:
			return getColumnCountName_5007Parser();
		case Maze.diagram.edit.parts.TurnRateName2EditPart.VISUAL_ID:
			return getTurnRateName_5009Parser();
		case Maze.diagram.edit.parts.StraightRateName2EditPart.VISUAL_ID:
			return getStraightRateName_5010Parser();
		case Maze.diagram.edit.parts.DecisionsRateName2EditPart.VISUAL_ID:
			return getDecisionsRateName_5011Parser();
		case Maze.diagram.edit.parts.StartPointNameEditPart.VISUAL_ID:
			return getStartPointName_5016Parser();
		case Maze.diagram.edit.parts.EndPointNameEditPart.VISUAL_ID:
			return getEndPointName_5017Parser();
		}
		return null;
	}

	/**
	* Utility method that consults ParserService
	* @generated
	*/
	public static IParser getParser(IElementType type, EObject object, String parserHint) {
		return ParserService.getInstance().getParser(new HintAdapter(type, object, parserHint));
	}

	/**
	* @generated
	*/
	public IParser getParser(IAdaptable hint) {
		String vid = (String) hint.getAdapter(String.class);
		if (vid != null) {
			return getParser(Maze.diagram.part.MazeVisualIDRegistry.getVisualID(vid));
		}
		View view = (View) hint.getAdapter(View.class);
		if (view != null) {
			return getParser(Maze.diagram.part.MazeVisualIDRegistry.getVisualID(view));
		}
		return null;
	}

	/**
	* @generated
	*/
	public boolean provides(IOperation operation) {
		if (operation instanceof GetParserOperation) {
			IAdaptable hint = ((GetParserOperation) operation).getHint();
			if (Maze.diagram.providers.MazeElementTypes.getElement(hint) == null) {
				return false;
			}
			return getParser(hint) != null;
		}
		return false;
	}

	/**
	* @generated
	*/
	private static class HintAdapter extends ParserHintAdapter {

		/**
		* @generated
		*/
		private final IElementType elementType;

		/**
		* @generated
		*/
		public HintAdapter(IElementType type, EObject object, String parserHint) {
			super(object, parserHint);
			assert type != null;
			elementType = type;
		}

		/**
		* @generated
		*/
		public Object getAdapter(Class adapter) {
			if (IElementType.class.equals(adapter)) {
				return elementType;
			}
			return super.getAdapter(adapter);
		}
	}

}
