/*
 * 
 */
package Maze.diagram.providers.assistants;

/**
 * @generated
 */
public class MazeModelingAssistantProviderOfStraightRate2EditPart
		extends Maze.diagram.providers.MazeModelingAssistantProvider {

}
