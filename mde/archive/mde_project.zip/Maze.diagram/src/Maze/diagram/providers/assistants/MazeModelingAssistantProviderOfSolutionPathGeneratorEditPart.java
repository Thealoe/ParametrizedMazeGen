/*
 * 
 */
package Maze.diagram.providers.assistants;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;

/**
 * @generated
 */
public class MazeModelingAssistantProviderOfSolutionPathGeneratorEditPart
		extends Maze.diagram.providers.MazeModelingAssistantProvider {

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getRelTypesOnSource(IAdaptable source) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnSource((Maze.diagram.edit.parts.SolutionPathGeneratorEditPart) sourceEditPart);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetRelTypesOnSource(Maze.diagram.edit.parts.SolutionPathGeneratorEditPart source) {
		List<IElementType> types = new ArrayList<IElementType>(1);
		types.add(Maze.diagram.providers.MazeElementTypes.SolutionPathGeneratorMbg_4002);
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getRelTypesOnSourceAndTarget(IAdaptable source, IAdaptable target) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source.getAdapter(IGraphicalEditPart.class);
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnSourceAndTarget((Maze.diagram.edit.parts.SolutionPathGeneratorEditPart) sourceEditPart,
				targetEditPart);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetRelTypesOnSourceAndTarget(
			Maze.diagram.edit.parts.SolutionPathGeneratorEditPart source, IGraphicalEditPart targetEditPart) {
		List<IElementType> types = new LinkedList<IElementType>();
		if (targetEditPart instanceof Maze.diagram.edit.parts.StackMazeBodyGeneratorEditPart) {
			types.add(Maze.diagram.providers.MazeElementTypes.SolutionPathGeneratorMbg_4002);
		}
		if (targetEditPart instanceof Maze.diagram.edit.parts.RandomMazeBodyGeneratorEditPart) {
			types.add(Maze.diagram.providers.MazeElementTypes.SolutionPathGeneratorMbg_4002);
		}
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getTypesForTarget(IAdaptable source, IElementType relationshipType) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source.getAdapter(IGraphicalEditPart.class);
		return doGetTypesForTarget((Maze.diagram.edit.parts.SolutionPathGeneratorEditPart) sourceEditPart,
				relationshipType);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetTypesForTarget(Maze.diagram.edit.parts.SolutionPathGeneratorEditPart source,
			IElementType relationshipType) {
		List<IElementType> types = new ArrayList<IElementType>();
		if (relationshipType == Maze.diagram.providers.MazeElementTypes.SolutionPathGeneratorMbg_4002) {
			types.add(Maze.diagram.providers.MazeElementTypes.StackMazeBodyGenerator_2005);
			types.add(Maze.diagram.providers.MazeElementTypes.RandomMazeBodyGenerator_2006);
		}
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getRelTypesOnTarget(IAdaptable target) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnTarget((Maze.diagram.edit.parts.SolutionPathGeneratorEditPart) targetEditPart);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetRelTypesOnTarget(Maze.diagram.edit.parts.SolutionPathGeneratorEditPart target) {
		List<IElementType> types = new ArrayList<IElementType>(1);
		types.add(Maze.diagram.providers.MazeElementTypes.RectangleGeneratorSpg_4001);
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getTypesForSource(IAdaptable target, IElementType relationshipType) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetTypesForSource((Maze.diagram.edit.parts.SolutionPathGeneratorEditPart) targetEditPart,
				relationshipType);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetTypesForSource(Maze.diagram.edit.parts.SolutionPathGeneratorEditPart target,
			IElementType relationshipType) {
		List<IElementType> types = new ArrayList<IElementType>();
		if (relationshipType == Maze.diagram.providers.MazeElementTypes.RectangleGeneratorSpg_4001) {
			types.add(Maze.diagram.providers.MazeElementTypes.RectangleGenerator_2003);
		}
		return types;
	}

}
