/*
 * 
 */
package Maze.diagram.providers;

import org.eclipse.gmf.tooling.runtime.providers.DefaultEditPartProvider;

/**
 * @generated
 */
public class MazeEditPartProvider extends DefaultEditPartProvider {

	/**
	* @generated
	*/
	public MazeEditPartProvider() {
		super(new Maze.diagram.edit.parts.MazeEditPartFactory(), Maze.diagram.part.MazeVisualIDRegistry.TYPED_INSTANCE,
				Maze.diagram.edit.parts.MazeDiagramEditPart.MODEL_ID);
	}

}
