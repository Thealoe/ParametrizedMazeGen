/*
 * 
 */
package Maze.diagram.providers.assistants;

/**
 * @generated
 */
public class MazeModelingAssistantProviderOfStraightRateEditPart
		extends Maze.diagram.providers.MazeModelingAssistantProvider {

}
