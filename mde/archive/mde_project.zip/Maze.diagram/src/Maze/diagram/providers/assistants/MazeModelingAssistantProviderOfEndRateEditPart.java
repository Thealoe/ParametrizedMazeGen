/*
 * 
 */
package Maze.diagram.providers.assistants;

/**
 * @generated
 */
public class MazeModelingAssistantProviderOfEndRateEditPart
		extends Maze.diagram.providers.MazeModelingAssistantProvider {

}
