/*
 * 
 */
package Maze.diagram.providers;

import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.ecore.ENamedElement;
import org.eclipse.gmf.runtime.emf.type.core.ElementTypeRegistry;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.tooling.runtime.providers.DiagramElementTypeImages;
import org.eclipse.gmf.tooling.runtime.providers.DiagramElementTypes;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.graphics.Image;

/**
 * @generated
 */
public class MazeElementTypes {

	/**
	* @generated
	*/
	private MazeElementTypes() {
	}

	/**
	* @generated
	*/
	private static Map<IElementType, ENamedElement> elements;

	/**
	* @generated
	*/
	private static DiagramElementTypeImages elementTypeImages = new DiagramElementTypeImages(
			Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().getItemProvidersAdapterFactory());

	/**
	* @generated
	*/
	private static Set<IElementType> KNOWN_ELEMENT_TYPES;

	/**
	* @generated
	*/
	public static final IElementType MazeDiagram_1000 = getElementType("Maze.diagram.MazeDiagram_1000"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType StackMazeBodyGenerator_2005 = getElementType(
			"Maze.diagram.StackMazeBodyGenerator_2005"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType RandomMazeBodyGenerator_2006 = getElementType(
			"Maze.diagram.RandomMazeBodyGenerator_2006"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType RectangleGenerator_2003 = getElementType("Maze.diagram.RectangleGenerator_2003"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType SolutionPathGenerator_2004 = getElementType(
			"Maze.diagram.SolutionPathGenerator_2004"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType DecisionsRate_3001 = getElementType("Maze.diagram.DecisionsRate_3001"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType StraightRate_3002 = getElementType("Maze.diagram.StraightRate_3002"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType TurnRate_3003 = getElementType("Maze.diagram.TurnRate_3003"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType RowCount_3004 = getElementType("Maze.diagram.RowCount_3004"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType ColumnCount_3005 = getElementType("Maze.diagram.ColumnCount_3005"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType TurnRate_3006 = getElementType("Maze.diagram.TurnRate_3006"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType StraightRate_3007 = getElementType("Maze.diagram.StraightRate_3007"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType DecisionsRate_3008 = getElementType("Maze.diagram.DecisionsRate_3008"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType RectangleGeneratorSpg_4001 = getElementType(
			"Maze.diagram.RectangleGeneratorSpg_4001"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType SolutionPathGeneratorMbg_4002 = getElementType(
			"Maze.diagram.SolutionPathGeneratorMbg_4002"); //$NON-NLS-1$

	/**
	* @generated
	*/
	public static ImageDescriptor getImageDescriptor(ENamedElement element) {
		return elementTypeImages.getImageDescriptor(element);
	}

	/**
	* @generated
	*/
	public static Image getImage(ENamedElement element) {
		return elementTypeImages.getImage(element);
	}

	/**
	* @generated
	*/
	public static ImageDescriptor getImageDescriptor(IAdaptable hint) {
		return getImageDescriptor(getElement(hint));
	}

	/**
	* @generated
	*/
	public static Image getImage(IAdaptable hint) {
		return getImage(getElement(hint));
	}

	/**
	* Returns 'type' of the ecore object associated with the hint.
	* 
	* @generated
	*/
	public static ENamedElement getElement(IAdaptable hint) {
		Object type = hint.getAdapter(IElementType.class);
		if (elements == null) {
			elements = new IdentityHashMap<IElementType, ENamedElement>();

			elements.put(MazeDiagram_1000, Maze.MazePackage.eINSTANCE.getMazeDiagram());

			elements.put(StackMazeBodyGenerator_2005, Maze.MazePackage.eINSTANCE.getStackMazeBodyGenerator());

			elements.put(RandomMazeBodyGenerator_2006, Maze.MazePackage.eINSTANCE.getRandomMazeBodyGenerator());

			elements.put(RectangleGenerator_2003, Maze.MazePackage.eINSTANCE.getRectangleGenerator());

			elements.put(SolutionPathGenerator_2004, Maze.MazePackage.eINSTANCE.getSolutionPathGenerator());

			elements.put(DecisionsRate_3001, Maze.MazePackage.eINSTANCE.getDecisionsRate());

			elements.put(StraightRate_3002, Maze.MazePackage.eINSTANCE.getStraightRate());

			elements.put(TurnRate_3003, Maze.MazePackage.eINSTANCE.getTurnRate());

			elements.put(RowCount_3004, Maze.MazePackage.eINSTANCE.getRowCount());

			elements.put(ColumnCount_3005, Maze.MazePackage.eINSTANCE.getColumnCount());

			elements.put(TurnRate_3006, Maze.MazePackage.eINSTANCE.getTurnRate());

			elements.put(StraightRate_3007, Maze.MazePackage.eINSTANCE.getStraightRate());

			elements.put(DecisionsRate_3008, Maze.MazePackage.eINSTANCE.getDecisionsRate());

			elements.put(RectangleGeneratorSpg_4001, Maze.MazePackage.eINSTANCE.getRectangleGenerator_Spg());

			elements.put(SolutionPathGeneratorMbg_4002, Maze.MazePackage.eINSTANCE.getSolutionPathGenerator_Mbg());
		}
		return (ENamedElement) elements.get(type);
	}

	/**
	* @generated
	*/
	private static IElementType getElementType(String id) {
		return ElementTypeRegistry.getInstance().getType(id);
	}

	/**
	* @generated
	*/
	public static boolean isKnownElementType(IElementType elementType) {
		if (KNOWN_ELEMENT_TYPES == null) {
			KNOWN_ELEMENT_TYPES = new HashSet<IElementType>();
			KNOWN_ELEMENT_TYPES.add(MazeDiagram_1000);
			KNOWN_ELEMENT_TYPES.add(StackMazeBodyGenerator_2005);
			KNOWN_ELEMENT_TYPES.add(RandomMazeBodyGenerator_2006);
			KNOWN_ELEMENT_TYPES.add(RectangleGenerator_2003);
			KNOWN_ELEMENT_TYPES.add(SolutionPathGenerator_2004);
			KNOWN_ELEMENT_TYPES.add(DecisionsRate_3001);
			KNOWN_ELEMENT_TYPES.add(StraightRate_3002);
			KNOWN_ELEMENT_TYPES.add(TurnRate_3003);
			KNOWN_ELEMENT_TYPES.add(RowCount_3004);
			KNOWN_ELEMENT_TYPES.add(ColumnCount_3005);
			KNOWN_ELEMENT_TYPES.add(TurnRate_3006);
			KNOWN_ELEMENT_TYPES.add(StraightRate_3007);
			KNOWN_ELEMENT_TYPES.add(DecisionsRate_3008);
			KNOWN_ELEMENT_TYPES.add(RectangleGeneratorSpg_4001);
			KNOWN_ELEMENT_TYPES.add(SolutionPathGeneratorMbg_4002);
		}
		return KNOWN_ELEMENT_TYPES.contains(elementType);
	}

	/**
	* @generated
	*/
	public static IElementType getElementType(int visualID) {
		switch (visualID) {
		case Maze.diagram.edit.parts.MazeDiagramEditPart.VISUAL_ID:
			return MazeDiagram_1000;
		case Maze.diagram.edit.parts.StackMazeBodyGeneratorEditPart.VISUAL_ID:
			return StackMazeBodyGenerator_2005;
		case Maze.diagram.edit.parts.RandomMazeBodyGeneratorEditPart.VISUAL_ID:
			return RandomMazeBodyGenerator_2006;
		case Maze.diagram.edit.parts.RectangleGeneratorEditPart.VISUAL_ID:
			return RectangleGenerator_2003;
		case Maze.diagram.edit.parts.SolutionPathGeneratorEditPart.VISUAL_ID:
			return SolutionPathGenerator_2004;
		case Maze.diagram.edit.parts.DecisionsRateEditPart.VISUAL_ID:
			return DecisionsRate_3001;
		case Maze.diagram.edit.parts.StraightRateEditPart.VISUAL_ID:
			return StraightRate_3002;
		case Maze.diagram.edit.parts.TurnRateEditPart.VISUAL_ID:
			return TurnRate_3003;
		case Maze.diagram.edit.parts.RowCountEditPart.VISUAL_ID:
			return RowCount_3004;
		case Maze.diagram.edit.parts.ColumnCountEditPart.VISUAL_ID:
			return ColumnCount_3005;
		case Maze.diagram.edit.parts.TurnRate2EditPart.VISUAL_ID:
			return TurnRate_3006;
		case Maze.diagram.edit.parts.StraightRate2EditPart.VISUAL_ID:
			return StraightRate_3007;
		case Maze.diagram.edit.parts.DecisionsRate2EditPart.VISUAL_ID:
			return DecisionsRate_3008;
		case Maze.diagram.edit.parts.RectangleGeneratorSpgEditPart.VISUAL_ID:
			return RectangleGeneratorSpg_4001;
		case Maze.diagram.edit.parts.SolutionPathGeneratorMbgEditPart.VISUAL_ID:
			return SolutionPathGeneratorMbg_4002;
		}
		return null;
	}

	/**
	* @generated
	*/
	public static final DiagramElementTypes TYPED_INSTANCE = new DiagramElementTypes(elementTypeImages) {

		/**
		* @generated
		*/
		@Override

		public boolean isKnownElementType(IElementType elementType) {
			return Maze.diagram.providers.MazeElementTypes.isKnownElementType(elementType);
		}

		/**
		* @generated
		*/
		@Override

		public IElementType getElementTypeForVisualId(int visualID) {
			return Maze.diagram.providers.MazeElementTypes.getElementType(visualID);
		}

		/**
		* @generated
		*/
		@Override

		public ENamedElement getDefiningNamedElement(IAdaptable elementTypeAdapter) {
			return Maze.diagram.providers.MazeElementTypes.getElement(elementTypeAdapter);
		}
	};

}
