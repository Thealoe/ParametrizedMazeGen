/*
 * 
 */
package Maze.diagram.providers.assistants;

/**
 * @generated
 */
public class MazeModelingAssistantProviderOfMazeCellEditPart
		extends Maze.diagram.providers.MazeModelingAssistantProvider {

}
