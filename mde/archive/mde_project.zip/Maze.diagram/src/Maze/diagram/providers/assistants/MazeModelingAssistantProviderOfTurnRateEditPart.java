/*
 * 
 */
package Maze.diagram.providers.assistants;

/**
 * @generated
 */
public class MazeModelingAssistantProviderOfTurnRateEditPart
		extends Maze.diagram.providers.MazeModelingAssistantProvider {

}
