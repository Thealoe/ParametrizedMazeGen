/*
 * 
 */
package Maze.diagram.providers.assistants;

/**
 * @generated
 */
public class MazeModelingAssistantProviderOfColumnCountEditPart
		extends Maze.diagram.providers.MazeModelingAssistantProvider {

}
