/*
 * 
 */
package Maze.diagram.providers.assistants;

/**
 * @generated
 */
public class MazeModelingAssistantProviderOfDecisionsRate2EditPart
		extends Maze.diagram.providers.MazeModelingAssistantProvider {

}
