/*
 * 
 */
package Maze.diagram.providers;

/**
 * @generated
 */
public class ElementInitializers {

	protected ElementInitializers() {
		// use #getInstance to access cached instance
	}

	/**
	* @generated
	*/
	public static ElementInitializers getInstance() {
		ElementInitializers cached = Maze.diagram.part.MazeDiagramEditorPlugin.getInstance().getElementInitializers();
		if (cached == null) {
			Maze.diagram.part.MazeDiagramEditorPlugin.getInstance()
					.setElementInitializers(cached = new ElementInitializers());
		}
		return cached;
	}
}
