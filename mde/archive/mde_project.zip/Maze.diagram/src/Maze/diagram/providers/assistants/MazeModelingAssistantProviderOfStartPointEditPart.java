/*
 * 
 */
package Maze.diagram.providers.assistants;

/**
 * @generated
 */
public class MazeModelingAssistantProviderOfStartPointEditPart
		extends Maze.diagram.providers.MazeModelingAssistantProvider {

}
