/*
 * 
 */
package Maze.diagram.providers;

import org.eclipse.gmf.runtime.common.ui.services.icon.IIconProvider;
import org.eclipse.gmf.tooling.runtime.providers.DefaultElementTypeIconProvider;

/**
 * @generated
 */
public class MazeIconProvider extends DefaultElementTypeIconProvider implements IIconProvider {

	/**
	* @generated
	*/
	public MazeIconProvider() {
		super(Maze.diagram.providers.MazeElementTypes.TYPED_INSTANCE);
	}

}
