/*
 * 
 */
package Maze.diagram.providers.assistants;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;

/**
 * @generated
 */
public class MazeModelingAssistantProviderOfMazeDiagramEditPart
		extends Maze.diagram.providers.MazeModelingAssistantProvider {

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getTypesForPopupBar(IAdaptable host) {
		List<IElementType> types = new ArrayList<IElementType>(4);
		types.add(Maze.diagram.providers.MazeElementTypes.StackMazeBodyGenerator_2005);
		types.add(Maze.diagram.providers.MazeElementTypes.RandomMazeBodyGenerator_2006);
		types.add(Maze.diagram.providers.MazeElementTypes.RectangleGenerator_2003);
		types.add(Maze.diagram.providers.MazeElementTypes.SolutionPathGenerator_2004);
		return types;
	}

}
