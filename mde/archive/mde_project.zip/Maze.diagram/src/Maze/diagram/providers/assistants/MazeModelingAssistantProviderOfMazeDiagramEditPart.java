/*
 * 
 */
package Maze.diagram.providers.assistants;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;

/**
 * @generated
 */
public class MazeModelingAssistantProviderOfMazeDiagramEditPart
		extends Maze.diagram.providers.MazeModelingAssistantProvider {

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getTypesForPopupBar(IAdaptable host) {
		List<IElementType> types = new ArrayList<IElementType>(4);
		types.add(Maze.diagram.providers.MazeElementTypes.RectangleGenerator_2001);
		types.add(Maze.diagram.providers.MazeElementTypes.ForcePatternGenerator_2002);
		types.add(Maze.diagram.providers.MazeElementTypes.SolutionPathGenerator_2003);
		types.add(Maze.diagram.providers.MazeElementTypes.MazeBodyGenerator_2004);
		return types;
	}

}
