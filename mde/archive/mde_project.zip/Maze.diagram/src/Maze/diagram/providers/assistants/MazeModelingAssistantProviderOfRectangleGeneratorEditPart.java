/*
 * 
 */
package Maze.diagram.providers.assistants;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;

/**
 * @generated
 */
public class MazeModelingAssistantProviderOfRectangleGeneratorEditPart
		extends Maze.diagram.providers.MazeModelingAssistantProvider {

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getRelTypesOnSource(IAdaptable source) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnSource((Maze.diagram.edit.parts.RectangleGeneratorEditPart) sourceEditPart);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetRelTypesOnSource(Maze.diagram.edit.parts.RectangleGeneratorEditPart source) {
		List<IElementType> types = new ArrayList<IElementType>(1);
		types.add(Maze.diagram.providers.MazeElementTypes.RectangleGeneratorFpg_4001);
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getRelTypesOnSourceAndTarget(IAdaptable source, IAdaptable target) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source.getAdapter(IGraphicalEditPart.class);
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnSourceAndTarget((Maze.diagram.edit.parts.RectangleGeneratorEditPart) sourceEditPart,
				targetEditPart);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetRelTypesOnSourceAndTarget(Maze.diagram.edit.parts.RectangleGeneratorEditPart source,
			IGraphicalEditPart targetEditPart) {
		List<IElementType> types = new LinkedList<IElementType>();
		if (targetEditPart instanceof Maze.diagram.edit.parts.ForcePatternGeneratorEditPart) {
			types.add(Maze.diagram.providers.MazeElementTypes.RectangleGeneratorFpg_4001);
		}
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getTypesForTarget(IAdaptable source, IElementType relationshipType) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source.getAdapter(IGraphicalEditPart.class);
		return doGetTypesForTarget((Maze.diagram.edit.parts.RectangleGeneratorEditPart) sourceEditPart,
				relationshipType);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetTypesForTarget(Maze.diagram.edit.parts.RectangleGeneratorEditPart source,
			IElementType relationshipType) {
		List<IElementType> types = new ArrayList<IElementType>();
		if (relationshipType == Maze.diagram.providers.MazeElementTypes.RectangleGeneratorFpg_4001) {
			types.add(Maze.diagram.providers.MazeElementTypes.ForcePatternGenerator_2002);
		}
		return types;
	}

}
