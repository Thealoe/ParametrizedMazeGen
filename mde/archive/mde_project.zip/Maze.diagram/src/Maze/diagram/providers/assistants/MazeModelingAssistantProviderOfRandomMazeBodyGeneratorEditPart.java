/*
 * 
 */
package Maze.diagram.providers.assistants;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;

/**
 * @generated
 */
public class MazeModelingAssistantProviderOfRandomMazeBodyGeneratorEditPart
		extends Maze.diagram.providers.MazeModelingAssistantProvider {

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getRelTypesOnTarget(IAdaptable target) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnTarget((Maze.diagram.edit.parts.RandomMazeBodyGeneratorEditPart) targetEditPart);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetRelTypesOnTarget(Maze.diagram.edit.parts.RandomMazeBodyGeneratorEditPart target) {
		List<IElementType> types = new ArrayList<IElementType>(1);
		types.add(Maze.diagram.providers.MazeElementTypes.SolutionPathGeneratorMbg_4002);
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getTypesForSource(IAdaptable target, IElementType relationshipType) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetTypesForSource((Maze.diagram.edit.parts.RandomMazeBodyGeneratorEditPart) targetEditPart,
				relationshipType);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetTypesForSource(Maze.diagram.edit.parts.RandomMazeBodyGeneratorEditPart target,
			IElementType relationshipType) {
		List<IElementType> types = new ArrayList<IElementType>();
		if (relationshipType == Maze.diagram.providers.MazeElementTypes.SolutionPathGeneratorMbg_4002) {
			types.add(Maze.diagram.providers.MazeElementTypes.SolutionPathGenerator_2004);
		}
		return types;
	}

}
