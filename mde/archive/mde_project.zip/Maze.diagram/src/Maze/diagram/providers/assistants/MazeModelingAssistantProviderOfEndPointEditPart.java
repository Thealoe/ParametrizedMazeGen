/*
 * 
 */
package Maze.diagram.providers.assistants;

/**
 * @generated
 */
public class MazeModelingAssistantProviderOfEndPointEditPart
		extends Maze.diagram.providers.MazeModelingAssistantProvider {

}
