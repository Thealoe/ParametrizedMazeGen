/*
 * 
 */
package Maze.diagram.providers.assistants;

/**
 * @generated
 */
public class MazeModelingAssistantProviderOfTurnRate2EditPart
		extends Maze.diagram.providers.MazeModelingAssistantProvider {

}
