/*
 * 
 */
package Maze.diagram.providers.assistants;

/**
 * @generated
 */
public class MazeModelingAssistantProviderOfDecisionsRateEditPart
		extends Maze.diagram.providers.MazeModelingAssistantProvider {

}
