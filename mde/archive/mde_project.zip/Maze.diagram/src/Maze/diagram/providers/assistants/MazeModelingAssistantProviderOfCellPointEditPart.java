/*
 * 
 */
package Maze.diagram.providers.assistants;

/**
 * @generated
 */
public class MazeModelingAssistantProviderOfCellPointEditPart
		extends Maze.diagram.providers.MazeModelingAssistantProvider {

}
