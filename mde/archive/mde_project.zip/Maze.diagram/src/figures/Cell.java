package figures;

import org.eclipse.draw2d.ImageFigure;
import activator.PluginActivator;

public class Cell extends ImageFigure {
    public Cell() {
    	super(PluginActivator.imageDescriptorFromPlugin(PluginActivator.ID,"icons/person.png").createImage(), 0);
    }
}